<meta charset="UTF-8">
<title>NECO India | Dashboard</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<!-- bootstrap 3.0.2 -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- font Awesome -->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- Ionicons -->
<link href="css/ionicons.min.css" rel="stylesheet" type="text/css" />
<!-- Morris chart -->
<link href="css/morris/morris.css" rel="stylesheet" type="text/css" />
<!-- jvectormap -->
<link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
<!-- fullCalendar -->
<link href="css/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
<!-- Daterange picker -->
<link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!-- bootstrap wysihtml5 - text editor -->
<link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
<!-- Theme style -->
<link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<link rel="icon" type="image/png" sizes="32x32" href="img/favicon.png">

<!-- date picker start -->

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">

<!-- datepicker -->
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- datepicker -->

<style type="text/css">
    body{
        background-color: lightgray;
        /*background-image: url('img/neco_logo.png');*/
        background-repeat: no-repeat;
        background-position: relative;
    }

    .content {
        padding: 20px 15px;
        /*background: #a59b9b;*/
        /*background: #a29786;*/
        /*background: #cfddee;*/
        /*background-image: url('img/neco_logo.png');
        background-repeat: no-repeat;
        background-position: center;*/
    }
</style>
<script>
    $( function() {
        $( "#com_sst_dt" ).datepicker({
            dateFormat: 'dd-mm-y',
            changeMonth: true,
            changeYear: true
        });
    } );
    $( function() {
        $( "#com_cst_dt" ).datepicker({
            dateFormat: 'dd-mm-y',
            changeMonth: true,
            changeYear: true
        });
    } );
    $( function() {
        $( "#sup_sstdt" ).datepicker({
            dateFormat: 'dd-mm-y',
            changeMonth: true,
            changeYear: true
        });
    } );
    $( function() {
        $( "#sup_cstdt" ).datepicker({
            dateFormat: 'dd-mm-y',
            changeMonth: true,
            changeYear: true
        });
    } );
    $( function() {
        $( "#mat_opdate" ).datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    } );  
    $( function() {
        $( "#sub_opbaldt" ).datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    } );      
    $( function() {
        $( "#acm_baldt" ).datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    } );      
    $( function() {
        $( "#bkm_baldt" ).datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true
        });
    } );      
    $( function() {
        $( "#req_dt" ).datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            onClose: function ()
            {
                this.focus();
            }
        });
    } );
    $( function() {
        $( "#poh_po_dt" ).datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            minDate: 0,
            maxDate: 0,
            onClose: function ()
            {
                this.focus();
            }
        });
    } );
    $( function() {
        $( "#poh_exp_dt" ).datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            minDate: 0,
            onClose: function ()
            {
                this.focus();
            }
        });
    } ); 
</script>

<!-- datepicker ends -->

<script type="text/javascript">
    window.onload = function() {
      var input = document.getElementById("comm_pass").focus();
    }

    // prevent form submit using enter key 
    $(document).ready(function() {
      $(window).keydown(function(event){
        if(event.keyCode == 13) {
          event.preventDefault();
          return false;
        }
      });
    });

    // hide error and success message dive after 5 sec
    setTimeout(function() {
      $(".message").fadeOut().empty();
    }, 7000);

    // check input is number only
    function CheckInputNumFormat(value){
        if (value != '' && isNaN(value)) {
            alert("Please enter number only.");
        }
    }

    // change format of input to decimal 
    function setNumberDecimal(data) {
        if (data.value != '') {
            data.value = parseFloat(data.value).toFixed(2);
        }else{
            data.value = 0.00;
        }
    }

    // refresh page
    function pageRefresh(){
        window.location = window.location.href;
    }

</script>

<!-- Autocomplete start -->

<script>
    $(function() {

        $( "#poh_po_type" ).autocomplete({
            source: 'includes/view_details.php?fldType=int&fldName=cod_code&tblName=codecat&cdPrfx=15'
        });

        $( "#poh_supcd" ).autocomplete({
            source: 'includes/view_details.php?fldType=str&fldName=sup_supcd&tblName=supcat'
        });

        $( "#poh_stax_cd" ).autocomplete({
            source: 'includes/view_details.php?fldType=int&fldName=cod_code&tblName=codecat&cdPrfx=1'
        });

        $( "#poh_excise_cd" ).autocomplete({
            source: 'includes/view_details.php?fldType=int&fldName=cod_code&tblName=codecat&cdPrfx=2'
        });

        $( "#poh_pmnt_terms" ).autocomplete({
            source: 'includes/view_details.php?fldType=int&fldName=cod_code&tblName=codecat&cdPrfx=13'
        });

        $( "#pod_item" ).autocomplete({
            source: 'includes/view_details.php?fldType=int&fldName=cod_code&tblName=codecat&cdPrfx=13'
        });
        
    });
</script>

<!-- Autocomplete ends -->

<script type="text/javascript">

    // validation for company password check
    function CheckComPass(){
        var ComPass = document.getElementById('comm_pass');
    	var FrmNm = document.getElementById('frm_nm');
        if(ComPass.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // unset loading image
                    document.getElementById("ComPassErrorSpan").innerHTML = '';
                    var value = xmlhttp.responseText;
                    if(value.length < 1)
                    {
                        document.getElementById('ComPassErrorSpan').innerHTML="Invalid Password";
                        ComPass.focus();
                    }
                    else
                    {
                        if (value == 'e') {
                            $('#upd').removeClass('btn btn-success');
                            $('#upd').addClass('btn btn-default');
                            $('#del').removeClass('btn btn-success');
                            $('#del').addClass('btn btn-default');
                            $('#prnt').removeClass('btn btn-success');
                            $('#prnt').addClass('btn btn-default');
                            $('#can').removeClass('btn btn-success');
                            $('#can').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-success');
                            $('#app').addClass('btn btn-default');

                            $('#ent').removeClass('btn btn-default');
                            $('#ent').addClass('btn btn-success');  
                        }else if (value == 'u') {
                            $('#ent').removeClass('btn btn-success');
                            $('#ent').addClass('btn btn-default');
                            $('#del').removeClass('btn btn-success');
                            $('#del').addClass('btn btn-default');
                            $('#prnt').removeClass('btn btn-success');
                            $('#prnt').addClass('btn btn-default');
                            $('#can').removeClass('btn btn-success');
                            $('#can').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-success');
                            $('#app').addClass('btn btn-default');

                            $('#upd').removeClass('btn btn-default');
                            $('#upd').addClass('btn btn-success');
                        }else if (value == 'd') {
                            $('#ent').removeClass('btn btn-success');
                            $('#ent').addClass('btn btn-default');                            
                            $('#upd').removeClass('btn btn-success');
                            $('#upd').addClass('btn btn-default');
                            $('#prnt').removeClass('btn btn-success');
                            $('#prnt').addClass('btn btn-default');
                            $('#can').removeClass('btn btn-success');
                            $('#can').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-success');
                            $('#app').addClass('btn btn-default');                           

                            $('#del').removeClass('btn btn-default');
                            $('#del').addClass('btn btn-success');
                        }else if (value == 'p') {
                            $('#ent').removeClass('btn btn-success');
                            $('#ent').addClass('btn btn-default');                            
                            $('#upd').removeClass('btn btn-success');
                            $('#upd').addClass('btn btn-default');
                            $('#del').removeClass('btn btn-success');
                            $('#del').addClass('btn btn-default');
                            $('#can').removeClass('btn btn-success');
                            $('#can').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-success');
                            $('#app').addClass('btn btn-default');

                            $('#prnt').removeClass('btn btn-default');
                            $('#prnt').addClass('btn btn-success');
                        }else if (value == 'c') {
                            $('#ent').removeClass('btn btn-success');
                            $('#ent').addClass('btn btn-default');                            
                            $('#upd').removeClass('btn btn-success');
                            $('#upd').addClass('btn btn-default');
                            $('#del').removeClass('btn btn-success');
                            $('#del').addClass('btn btn-default');

                            $('#prnt').removeClass('btn btn-success');
                            $('#prnt').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-success');
                            $('#app').addClass('btn btn-default');

                            $('#can').removeClass('btn btn-default');
                            $('#can').addClass('btn btn-success');
                        }else if (value == 'a') {
                            $('#ent').removeClass('btn btn-success');
                            $('#ent').addClass('btn btn-default');                            
                            $('#upd').removeClass('btn btn-success');
                            $('#upd').addClass('btn btn-default');
                            $('#del').removeClass('btn btn-success');
                            $('#del').addClass('btn btn-default');

                            $('#prnt').removeClass('btn btn-success');
                            $('#prnt').addClass('btn btn-default');

                            $('#can').removeClass('btn btn-success');
                            $('#can').addClass('btn btn-default');

                            $('#app').removeClass('btn btn-default');
                            $('#app').addClass('btn btn-success');
                        }

                        document.getElementById('ComPassErrorSpan').innerHTML="";

                        $('#cmp_cd').removeAttr('readonly');
                        $('#unt_cd').removeAttr('readonly');
                        $('#cmp_cd').focus();
                        $('#cod_prefix').removeAttr('readonly');
                        $('#com_com').removeAttr('readonly');
                        $('#dep_prefix').removeAttr('readonly');
                        $('#esup_supcd').removeAttr('readonly');
                        $('#gen_accd').removeAttr('readonly');
                    }
                }
            }
            // Set here the image before sending request
            document.getElementById("ComPassErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/inv_ctlg_cmp_pass_chck.php?q="+ComPass.value+"&u="+FrmNm.value,true);
            xmlhttp.send();
        }else{
            ComPass.focus();
        }
    }

    // validation for company code check
    function CheckComCd(){
        var ComCd = document.getElementById('com_com');

        if(ComCd.value != "")
        {

            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Unset here the image before sending request
                    document.getElementById("ComCdErrorSpan").innerHTML = '';
                    var value = xmlhttp.responseText;
                    if(value.length < 1)
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="Invalid Company Code";
                        document.getElementById('ComCdName').innerHTML="";
                        ComCd.focus();
                    }
                    else
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="";
                        document.getElementById('ComCdName').innerHTML=value;
                        $("#itm_item").removeAttr('readonly');
                        $("#sup_supcd").removeAttr('readonly');
                        $("#mat_unit").removeAttr('readonly');
                    }
                }
              }
            // Set here the image before sending request
            document.getElementById("ComCdErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/cmp_cd_chck.php?q="+ComCd.value,true);
            xmlhttp.send();
        }
    }


</script>


<!-- 
////////////////////////////////////////////////////////////////////////////////////////////

                                    Invac section start

//////////////////////////////////////////////////////////////////////////////////////////// -->


<script type="text/javascript">

    /////////////////////////////////////////////////////////////////////////////////////////

    // validation for company code and unit code check
    function CheckCmpCdUntCd(){
        var CmpCd = document.getElementById('cmp_cd');
    	var UntCd = document.getElementById('unt_cd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(CmpCd.value != "" && UntCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // unset loading image
                    document.getElementById("CmpUntCdErrorSpan").innerHTML = '';
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.a != '')
                    {
                        if ((data.passActn == 'u' || data.passActn == 'q') && FrmNm.value == 'comcat') {
                            $("input").removeAttr('readonly');
                            document.getElementById("com_name").value=data.c;
                            document.getElementById("com_uname").value=data.d;                        
                            document.getElementById("com_add1").value=data.e;
                            document.getElementById("com_add2").value=data.f;
                            document.getElementById("com_add3").value=data.g;
                            document.getElementById("com_sst_no").value=data.h;
                            document.getElementById("com_sst_dt").value=data.i;
                            document.getElementById("com_cst_no").value=data.j;
                            document.getElementById("com_cst_dt").value=data.k;
                            document.getElementById("com_gram").value=data.l;
                            document.getElementById("com_tel").value=data.m;
                            document.getElementById("com_collectorate").value=data.n;
                            document.getElementById("com_range").value=data.o;
                            document.getElementById("com_division").value=data.p;
                            document.getElementById("com_pla_no").value=data.q;
                            document.getElementById("com_cex_no").value=data.r;
                            document.getElementById("com_pf_no").value=data.s;
                            document.getElementById("com_ecc_no").value=data.t;
                            document.getElementById("com_mast").value=data.u;
                            document.getElementById("com_dbf").value=data.v;
                            document.getElementById("com_tin_no").value=data.w;
                            document.getElementById("com_ctin_no").value=data.x;
                            document.getElementById("com_stct_cd").value=data.y;
                            document.getElementById("com_gstin_no").value=data.z;
                            document.getElementById('CmpUntCdErrorSpan').innerHTML="Record Found";

                        }else if(data.passActn == 'd' && FrmNm.value == 'comcat'){
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+CmpCd.value+"&u="+UntCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                alert("Record Deleted Successfully.");
                                window.location.reload();
                            }
                        }if(data.passActn == 'e' && FrmNm.value == 'comcat'){
                            document.getElementById('CmpUntCdErrorSpan').innerHTML="Entry Already Exists.";
                            UntCd.focus();
                        }
                        
                    }
                    else
                    {
                        if(data.passActn == 'e' && FrmNm.value == 'comcat'){
                            document.getElementById('CmpUntCdErrorSpan').innerHTML="New Entry";
                            document.getElementById("com_name").value="";
                            document.getElementById("com_uname").value="" 
                            document.getElementById("com_add1").value="";
                            document.getElementById("com_add2").value="";
                            document.getElementById("com_add3").value="";
                            document.getElementById("com_sst_no").value="";
                            document.getElementById("com_sst_dt").value="";
                            document.getElementById("com_cst_no").value="";
                            document.getElementById("com_cst_dt").value="";
                            document.getElementById("com_gram").value="";
                            document.getElementById("com_tel").value="";
                            document.getElementById("com_collectorate").value="";
                            document.getElementById("com_range").value="";
                            document.getElementById("com_division").value="";
                            document.getElementById("com_pla_no").value="";
                            document.getElementById("com_cex_no").value="";
                            document.getElementById("com_pf_no").value="";
                            document.getElementById("com_ecc_no").value="";
                            document.getElementById("com_mast").value="";
                            document.getElementById("com_dbf").value="";
                            document.getElementById("com_tin_no").value="";
                            document.getElementById("com_ctin_no").value="";
                            document.getElementById("com_stct_cd").value="";
                            document.getElementById("com_gstin_no").value="";
                            //$("#com_name").removeAttr('readonly');
                            $("input").removeAttr('readonly');
                        }else{
                            document.getElementById('CmpUntCdErrorSpan').innerHTML="Invalid Input";
                            UntCd.focus();
                            $("input").attr('readonly');
                        }
                    }
                }
            }

            // Set here the image before sending request
            document.getElementById("CmpUntCdErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/inv_ctlg_cmp_unt_cd_chck.php?q="+CmpCd.value+"&u="+UntCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
            
            xmlhttp.send();
        }
    }


    // // validation for company form mandatory fields
    // function RmvAttrComFrmFldsComUnm(){
    //     var ComNm = document.getElementById('com_name');
    //     if (ComNm.value.trim() != "") {
    //         $("#com_uname").removeAttr('readonly');
    //     }
    // }

    // function RmvAttrComFrmFldsComAdd(){
    //     var ComUnm = document.getElementById('com_uname');
    //     if (ComUnm.value.trim() != "") {
    //         $("#com_add1").removeAttr('readonly');
    //     }
    // }

    // function RmvAttrComFrmFldsComAll(){
    //     var ComAdd = document.getElementById('com_add1');
    //     if (ComAdd.value.trim() != "") {
    //         $("input").removeAttr('readonly');
    //     }
    // }


    /////////////////////////////////////////////////////////////////////////////////////////

    // validation for General code catalog
    function ChckFrmFldsPrfxCode(){
        var CdPrfx = document.getElementById('cod_prefix');
        var Cd = document.getElementById('cod_code');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(CdPrfx.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(value.length >= 1)
                    {
                        //alert(data.passActn);
                        document.getElementById("cod_code").value=data.a;
                        $("input").removeAttr('readonly');
                        if(data.passActn == 'e'){
                            document.getElementById('CdEntCdErrorSpan').innerHTML="New Entry";                            
                        }
                    }
                    else
                    {
                        if(data.passActn == 'u'){
                            document.getElementById('CdEntCdErrorSpan').innerHTML="Duplicate Entry";                            
                        }
                        document.getElementById("cod_code").value="";
                        document.getElementById("cod_desc").value="";
                        $("input").removeAttr('readonly');
                    }
                }
              }

                xmlhttp.open("GET","includes/inv_ctlg_gnrl_prfx_cd_chck.php?q="+CdPrfx.value+"&u="+Cd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                xmlhttp.send();
        }
    }

    // validation for General code catalog
    function ChckFrmFldsCodeDesc(){
        var CdPrfx = document.getElementById('cod_prefix');
        var Cd = document.getElementById('cod_code');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(CdPrfx.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.a != '')
                    {
                        if(data.passActn == 'e' && FrmNm.value == 'codent'){
                            document.getElementById('CdEntCdErrorSpan').innerHTML="Entry Already Exists.";
                            document.getElementById("cod_desc").value=data.a;
                        }else if(data.passActn == 'u' && FrmNm.value == 'codent') {
                            $("input").removeAttr('readonly');
                            document.getElementById("cod_desc").value=data.a;
                        }else if (data.passActn == 'd' && FrmNm.value == 'codent' && Cd.value != ''){
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+CdPrfx.value+"&u="+Cd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                alert("Record Deleted Successfully.");
                                Cd.focus();
                                window.location.reload();
                            }
                        }
                    }
                    else if(data.a == '')
                    {
                        if(data.passActn == 'e' && FrmNm.value == 'codent'){
                            document.getElementById('CdEntCdErrorSpan').innerHTML="New Entry";
                            document.getElementById("cod_desc").value="";
                        }else if(data.passActn == 'u' && FrmNm.value == 'codent') {
                            document.getElementById('CdEntCdErrorSpan').innerHTML="Entry does not exists.";
                            $('#cod_desc').hide();
                            document.getElementById("cod_desc").value="";
                        }
                    }
                }
              }
                xmlhttp.open("GET","includes/inv_ctlg_gnrl_prfx_cd_chck.php?q="+CdPrfx.value+"&u="+Cd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                xmlhttp.send();
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////


    // validation for Material catalogue item not check
    function CheckMtrlItmNo(){
        var ItmNo = document.getElementById('itm_item');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');       

        if(ItmNo.value != "")
            {
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                  xmlhttp=new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function()
                {   
                  if (xmlhttp.readyState==4 && xmlhttp.status==200)
                    {
                        var value = xmlhttp.responseText;
                        data = JSON.parse(value);

                        if (data.passActn == 'e') {
                            if(ItmNo.value != "" && ItmNo.value.length != 7)
                            {
                                document.getElementById('MtrlItmNoErrorSpan').innerHTML="ITEM CODE MUST BE SEVEN DIGIT...!!!";
                                $("#itm_item").focus();
                            }else if(data.itm_item == ''){
                                document.getElementById('MtrlItmNoErrorSpan').innerHTML="";
                                $("#itm_desc").removeAttr('readonly');
                                $("#itm_part").removeAttr('readonly');
                                $("#itm_uom").removeAttr('readonly');
                            }else if(data.itm_item != ''){
                                document.getElementById('MtrlItmNoErrorSpan').innerHTML="Entry Already Exists.";
                                ItmNo.focus();
                            }
                        }else if (data.passActn == 'u') {
                            if(value.length >= 1)
                            {

                                if(ItmNo.value != "" && ItmNo.value.length != 7)
                                {
                                    document.getElementById('MtrlItmNoErrorSpan').innerHTML="ITEM CODE MUST BE SEVEN DIGIT...!!!";
                                    $("#itm_item").focus();
                                }else{
                                    document.getElementById('MtrlItmNoErrorSpan').innerHTML="";
                                
                                    if (data.itm_item != "") {
                                        document.getElementById('MtrlItmNoErrorSpan').innerHTML="";
                                        $("#itm_desc").removeAttr('readonly');
                                        $("#itm_part").removeAttr('readonly');
                                        $("#itm_uom").removeAttr('readonly');
                                        document.getElementById("itm_desc").value=data.itm_desc;
                                        document.getElementById("itm_part").value=data.itm_part;
                                        document.getElementById("itm_uom").value=data.itm_uom;
                                        document.getElementById("itm_crossitm").value=data.itm_crossitm;
                                        document.getElementById("itm_modvat").value=data.itm_modvat;
                                        document.getElementById("itm_type").value=data.itm_type;
                                        document.getElementById("itm_cr_days").value=data.itm_cr_days;
                                        document.getElementById("itm_del_tag").value=data.itm_del_tag;
                                    }else{
                                        document.getElementById('MtrlItmNoErrorSpan').innerHTML="Invalid Item No.";
                                        $("#itm_item").focus();
                                        document.getElementById("itm_desc").value="";
                                        document.getElementById("itm_part").value="";
                                        document.getElementById("itm_uom").value="";
                                        document.getElementById("itm_crossitm").value="";
                                        document.getElementById("itm_modvat").value="";
                                        document.getElementById("itm_type").value="";
                                        document.getElementById("itm_cr_days").value="";
                                        document.getElementById("itm_del_tag").value="";
                                    }
                                }
                            }
                        }else if (data.passActn == 'd' && FrmNm.value == 'itemcat' && ItmNo.value != '') {
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+ItmNo.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                document.getElementById('MtrlItmNoErrorSpan').innerHTML="Item Deleted Successfully.";
                                alert("Record Deleted Successfully.");
                                ItmNo.focus();
                                window.location.reload();
                            }
                        }
                    }
                  }                  
                    xmlhttp.open("GET","includes/inv_ctlg_cmp_mtrl_itm_no_chck.php?q="+ItmNo.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
                    xmlhttp.send();
            }
    }


    // validation for unit of measurment check
    function CheckUntOfMsrmntCd(){
        var ComCd = document.getElementById('itm_uom');

        if(ComCd.value != "")
        {

            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    if(value.length < 1)
                    {
                        document.getElementById('UomErrorSpan').innerHTML="Invalid Unit Of Measurment";
                        document.getElementById('UomCdName').innerHTML="";
                        ComCd.focus();
                    }
                    else
                    {
                        document.getElementById('UomErrorSpan').innerHTML="";
                        document.getElementById('UomCdName').innerHTML=value;
                        $("#itm_crossitm").removeAttr('readonly');
                        $("#itm_modvat").removeAttr('readonly');
                        $("#itm_type").removeAttr('readonly');
                    }
                }
              }
            xmlhttp.open("GET","includes/cmp_unt_msrmnt_chck.php?q="+ComCd.value,true);
            xmlhttp.send();
        }
    }

    // validation for Item type and credit days check
    function CheckItmTypCrdtDys(){
        var ItmTyp = document.getElementById('itm_type');
        var val = ItmTyp.value;

        if(val == 'X' || val == 'A' || val == 'B' || val == 'C')
        {
            document.getElementById('ItmTypErrorSpan').innerHTML="";
            if (val == 'X') {
                document.getElementById('itm_cr_days').value="0";
            }else if (val == 'A') {
                document.getElementById('itm_cr_days').value="30";
            }else if (val == 'B') {
                document.getElementById('itm_cr_days').value="60";
            }else if (val == 'C') {
                document.getElementById('itm_cr_days').value="90";
            }
            $("#itm_del_tag").removeAttr('readonly');
        }else{
            document.getElementById('ItmTypErrorSpan').innerHTML="Invalid Item Type ..Enter In 'X', 'A', 'B' or 'C' ...!!";
            $("#itm_type").focus();
        }
    }

    //////////////////////////////////////////////////////////////////////////////////

     // validation for Depart./Cost Center Catalogue dep_code check
    function CheckDeptCostCd(){
        var PrfxCd = document.getElementById('dep_prefix');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');   

        if(PrfxCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);

                    if(value.length < 1)
                    {
                        document.getElementById('dep_cd').value="";
                    }
                    else
                    {
                        if (data.passActn == 'e') {
                            document.getElementById('dep_cd').value=data.a;
                            $("#dep_cd").removeAttr('readonly');
                        }else if(data.passActn == 'u'){
                            document.getElementById('dep_cd').value="";
                            $("#dep_cd").removeAttr('readonly');
                        }else if(data.passActn == 'd'){
                            document.getElementById('dep_cd').value="";
                            $("#dep_cd").removeAttr('readonly');
                        }
                    }
                }
            }
            xmlhttp.open("GET","includes/cmp_dept_cost_cd_chck.php?q="+PrfxCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }

    // validation for Depart./Cost Center Catalogue dep_code check
    function CheckDeptCostAvalblCd(){
        var PrfxCd = document.getElementById('dep_prefix');
        var DeptCd = document.getElementById('dep_cd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');   
        
        if(DeptCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    //alert(data.a);
                    if (data.passActn == 'e') {
                        if(data.a == false)
                        {
                            document.getElementById('DeptCostCdErrorSpan').innerHTML="Code Available";
                            $("#dep_desc").removeAttr('readonly');
                        }
                        else
                        {
                            document.getElementById('DeptCostCdErrorSpan').innerHTML="Code Not Available";
                            $("#dep_cd").focus();
                        }
                    }else if (data.passActn == 'u') {
                        if(data.a != false)
                        {
                            document.getElementById('DeptCostCdErrorSpan').innerHTML="Code Available";
                            $("#dep_desc").removeAttr('readonly');
                            document.getElementById('dep_desc').value=data.b;
                        }
                        else
                        {
                            document.getElementById('DeptCostCdErrorSpan').innerHTML="Code Not Available";
                            $("#dep_cd").focus();
                            document.getElementById('dep_desc').value="";
                        }
                    }else if (data.passActn == 'd' && FrmNm.value == 'deptent' && PrfxCd.value != '' && DeptCd.value != '') {
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+PrfxCd.value+"&u="+DeptCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                document.getElementById('DeptCostCdErrorSpan').innerHTML="Record Deleted Successfully.";
                                alert("Record Deleted Successfully.");
                                window.location.reload();
                            }
                    }
                }
              }
              
            xmlhttp.open("GET","includes/cmp_dept_cost_cd_chck.php?t="+PrfxCd.value+"&u="+DeptCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////

    // validation for Ecc Master ( Supplier ) Catalogue sup code check
    function CheckEsupCd(){
        var EsupCd = document.getElementById('esup_supcd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');   

        if(EsupCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    //alert(data.a);
                    if(data.a != false)
                    {
                        if (data.passActn == 'e') {
                            document.getElementById('EsupCdErrorSpan').innerHTML="Record Already Exists.";
                            EsupCd.focus();
                        }else if(data.passActn == 'u'){
                            document.getElementById('EsupCdErrorSpan').innerHTML="";
                            $("#esup_name").removeAttr('readonly');
                            $("#esup_eccno").removeAttr('readonly');
                            document.getElementById('esup_name').value=data.b;
                            document.getElementById('esup_eccno').value=data.c;
                        }else if(data.passActn == 'd' && FrmNm.value == 'supeccmst' && EsupCd.value != ''){
                                var strconfirm = confirm("Are you sure you want to delete?");
                                if (strconfirm == true) {

                                    xmlhttp.open("GET","includes/inv_record_del.php?q="+EsupCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                    document.getElementById('EsupCdErrorSpan').innerHTML="Record Deleted Successfully.";
                                    xmlhttp.send();
                                    document.getElementById('esup_supcd').value="";
                                    alert("Record Deleted Successfully.");
                                }
                        }
                    }
                    else
                    {
                        if (data.passActn == 'e') {
                            document.getElementById('EsupCdErrorSpan').innerHTML="";
                            $("#esup_name").removeAttr('readonly');
                            $("#esup_eccno").removeAttr('readonly');
                        }else if(data.passActn == 'u'){
                            document.getElementById('EsupCdErrorSpan').innerHTML="Record Not Found";
                            EsupCd.focus();
                            document.getElementById('esup_name').value="";
                            document.getElementById('esup_eccno').value="";
                        }else if(data.passActn == 'd'){
                            document.getElementById('dep_cd').value="";
                            $("#dep_cd").removeAttr('readonly');
                        }

                    }
                }
            }
            xmlhttp.open("GET","includes/sup_ecc_mstr_cd_chck.php?q="+EsupCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////

    // validation for supplier catalogue code check
    function CheckSupCatCd(){
        var SupCd = document.getElementById('sup_supcd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(SupCd.value != "" && SupCd.value.length == 4)
        {
            document.getElementById('SupCdErrorSpan').innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
                
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.a != "")
                    {
                        document.getElementById("sup_supcd").value=data.a;
                        document.getElementById("sup_name").value=data.b;
                        document.getElementById("sup_add1").value=data.c;
                        document.getElementById("sup_add2").value=data.d;
                        document.getElementById("sup_add3").value=data.e;
                        document.getElementById("sup_sstno").value=data.f;
                        document.getElementById("sup_sstdt").value=data.g;
                        document.getElementById("sup_cstno").value=data.h;
                        document.getElementById("sup_cstdt").value=data.i;

                        document.getElementById("sup_tinno").value=data.k;
                        document.getElementById("sup_ctinno").value=data.l;
                        document.getElementById("sup_panno").value=data.m;
                        document.getElementById("sup_email1").value=data.n;
                        document.getElementById("sup_email2").value=data.o;
                        document.getElementById("sup_website").value=data.p;
                        document.getElementById("sup_phone_no").value=data.q;
                        document.getElementById("sup_fax_no").value=data.r;
                        document.getElementById("sup_bank_name1").value=data.s;
                        document.getElementById("sup_bank_acct1").value=data.t;
                        document.getElementById("sup_bank_name2").value=data.u;
                        document.getElementById("sup_bank_acct2").value=data.v;
                        document.getElementById("sup_bank_name3").value=data.w;
                        document.getElementById("sup_bank_acct3").value=data.x;
                        document.getElementById("sup_bank_cd1").value=data.y;
                        document.getElementById("sup_bank_ifsc").value=data.z;
                        document.getElementById("sup_state").value=data.A;
                        document.getElementById("sup_city").value=data.B;
                        document.getElementById("sup_stct_cd").value=data.C;
                        document.getElementById("sup_gstin_no").value=data.D;

                        if (data.passActn == 'e' && FrmNm.value == 'supcat') {
                            document.getElementById('SupCdErrorSpan').innerHTML="Duplicate Entry";
                        }else if (data.passActn == 'u' && FrmNm.value == 'supcat') {
                            $("input").removeAttr('readonly');
                        }else if(data.passActn == 'q' && FrmNm.value == 'supcat'){
                            $("input").attr('readonly');
                        }else if(data.passActn == 'd' && FrmNm.value == 'supcat'){
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+SupCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                document.getElementById('SupCdErrorSpan').innerHTML="Record Deleted !";
                                alert("Record Deleted Successfully.");
                                window.location.reload();
                            }
                        }                        
                    }
                    else
                    {
                        document.getElementById("sup_name").value="";
                        document.getElementById("sup_add1").value="";
                        document.getElementById("sup_add2").value="";
                        document.getElementById("sup_add3").value="";
                        document.getElementById("sup_sstno").value="";
                        document.getElementById("sup_sstdt").value="";
                        document.getElementById("sup_cstno").value="";
                        document.getElementById("sup_cstdt").value="";
                        document.getElementById("sup_tinno").value="";
                        document.getElementById("sup_ctinno").value="";
                        document.getElementById("sup_panno").value="";
                        document.getElementById("sup_email1").value="";
                        document.getElementById("sup_email2").value="";
                        document.getElementById("sup_website").value="";
                        document.getElementById("sup_phone_no").value="";
                        document.getElementById("sup_fax_no").value="";
                        document.getElementById("sup_bank_name1").value="";
                        document.getElementById("sup_bank_acct1").value="";
                        document.getElementById("sup_bank_name2").value="";
                        document.getElementById("sup_bank_acct2").value="";
                        document.getElementById("sup_bank_name3").value="";
                        document.getElementById("sup_bank_acct3").value="";
                        document.getElementById("sup_bank_cd1").value="";
                        document.getElementById("sup_bank_ifsc").value="";
                        document.getElementById("sup_state").value="";
                        document.getElementById("sup_city").value="";
                        document.getElementById("sup_stct_cd").value="";
                        document.getElementById("sup_gstin_no").value="";
                        //$("#com_name").removeAttr('readonly');

                        if (data.passActn == 'e' && FrmNm.value == 'supcat') {
                            document.getElementById('SupCdErrorSpan').innerHTML="New Entry";
                            $("input").removeAttr('readonly');
                        }else if (data.passActn == 'u' && FrmNm.value == 'supcat') {
                            document.getElementById('SupCdErrorSpan').innerHTML="Not Found !";
                        }
                    }
                }
            }
            xmlhttp.open("GET","includes/inv_ctlg_cmp_sup_cd_chck.php?q="+SupCd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);

            xmlhttp.send();
        }else{
            document.getElementById('SupCdErrorSpan').innerHTML="Invalid !";
            SupCd.focus();
            SupCd.value="";
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // validation for company code check for material master
    function CheckMatMastComCd(){
        var ComCd = document.getElementById('com_com');
        var UserComCd = document.getElementById('user_com_cd');

        if(ComCd.value != "" && (ComCd.value == UserComCd.value))
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    if(value.length < 1)
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="Invalid Company Code";
                        document.getElementById('ComCdName').innerHTML="";
                        ComCd.focus();
                    }
                    else
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="";
                        document.getElementById('ComCdName').innerHTML=value;
                        $("#itm_item").removeAttr('readonly');
                        $("#sup_supcd").removeAttr('readonly');
                        $("#mat_unit").removeAttr('readonly');
                    }
                }
              }
            xmlhttp.open("GET","includes/cmp_cd_chck.php?q="+ComCd.value,true);
            xmlhttp.send();
        }else if(ComCd.value != "" && (ComCd.value != UserComCd.value)){
            document.getElementById('ComCdErrorSpan').innerHTML="Invalid Company Code";
            document.getElementById('ComCdName').innerHTML="";
            ComCd.focus();
        }
    }


    // validation for company code and unit code check
    function CheckMatMastUntCd(){
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');

        if(ComCd.value != "" && UntCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    //alert(data.length);
                    if(data.com_uname != '')
                    {
                        document.getElementById('ComUntCdErrorSpan').innerHTML="";
                        document.getElementById('ComUntCdName').innerHTML=data.com_uname;
                        document.getElementById('ComCdName').innerHTML=data.com_name;
                        $("#mat_item").removeAttr('readonly');
                        $("#sub_accd").removeAttr('readonly');
                        $("#acm_accd").removeAttr('readonly');
                        $("#bkm_code").removeAttr('readonly');
                        $("#bud_yy").removeAttr('readonly');
                        $("#bud_mm").removeAttr('readonly');
                        $("#bud_accd").removeAttr('readonly');
                        $("#req_dt").removeAttr('disabled');
                        $("#poh_po_dt").removeAttr('disabled');
                        $("#poh_inq_no").removeAttr('readonly');
                    }
                    else
                    {                        
                        document.getElementById('ComUntCdErrorSpan').innerHTML="Invalid Unit Code";
                        document.getElementById('ComUntCdName').innerHTML="";
                        UntCd.focus();
                    }
                }
              }
            xmlhttp.open("GET","includes/cmp_unt_cd_chck.php?q="+ComCd.value+"&u="+UntCd.value,true);
            xmlhttp.send();
        }
    }

    // validation for item code check
    function CheckMatMastItmCd(){
        var ItmCd = document.getElementById('mat_item');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');
        var UserComDbf = document.getElementById('user_com_dbf');
        var UserComCd = document.getElementById('user_com_cd');
        var UserUntCd = document.getElementById('mat_unit');

        if(ItmCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    //alert(data.length);
                    if(data.itm_desc != '')
                    {
                        if(data.passActn == 'u' && (data.mat_item != false || data.mat_item != '')) {
                            document.getElementById('ComItmCdErrorSpan').innerHTML="";
                            document.getElementById('ComItmCdName').innerHTML=data.itm_desc;
                            document.getElementById('mat_uom').innerHTML=data.cod_desc;
                            $("#mat_minlev").removeAttr('readonly');
                            $("#mat_maxlev").removeAttr('readonly');
                            $("#mat_ordlev").removeAttr('readonly');
                            $("#mat_location").removeAttr('readonly');
                            $("#mat_abc").removeAttr('readonly');
                            $("#mat_typ").removeAttr('readonly');
                            $("#mat_accd").removeAttr('readonly');
                            $("#mat_opqty").removeAttr('readonly');
                            $("#mat_oprate").removeAttr('readonly');
                            $("#mat_opdate").removeAttr('readonly');
                            $("#mat_budg").removeAttr('readonly');
                        
                            document.getElementById('mat_minlev').value=data.mat_minlev;
                            document.getElementById('mat_maxlev').value=data.mat_maxlev;
                            document.getElementById('mat_ordlev').value=data.mat_ordlev;
                            document.getElementById('mat_location').value=data.mat_location;
                            document.getElementById('mat_abc').value=data.mat_abc;
                            document.getElementById('mat_typ').value=data.mat_typ;
                            document.getElementById('mat_accd').value=data.mat_accd;
                            document.getElementById('mat_opqty').value=data.mat_opqty;
                            document.getElementById('mat_oprate').value=data.mat_oprate;
                            document.getElementById('mat_opdate').value=data.mat_opdate;
                            document.getElementById('mat_budg').value=data.mat_budg;

                        }else if(data.passActn == 'u' && (data.mat_item == false || data.mat_item == '')){
                            document.getElementById('ComItmCdErrorSpan').innerHTML="Invalid Item Code";
                            ItmCd.focus();
                        }else if(data.passActn == 'd' && (data.mat_item != false || data.mat_item != '')  && FrmNm.value == 'matmast'){

                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {

                                xmlhttp.open("GET","includes/inv_record_del.php?q="+ItmCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value+"&UserComDbf="+UserComDbf.value+"&UserUntCd="+UserUntCd.value+"&UserComCd="+UserComCd.value,true);
                                xmlhttp.send();
                                document.getElementById('ComItmCdErrorSpan').innerHTML="Record Has Been Deleted !";
                                alert("Record Deleted Successfully.");
                                window.location.reload();
                            }

                        }


                        if(data.passActn == 'e' && (data.mat_item != false || data.mat_item != '')) {

                            document.getElementById('ComItmCdErrorSpan').innerHTML="Duplicate Item Code Entry";
                            document.getElementById('ComItmCdName').innerHTML="";
                            ItmCd.focus();
                        }else if(data.passActn == 'e' && (data.mat_item == false || data.mat_item == '')) {
                            document.getElementById('ComItmCdErrorSpan').innerHTML="New Record Entry";
                            document.getElementById('mat_uom').innerHTML="UNIT OF MEASUREMENT";
                            document.getElementById('ComItmCdName').innerHTML="";
                            $("#mat_minlev").removeAttr('readonly');
                            $("#mat_maxlev").removeAttr('readonly');
                            $("#mat_ordlev").removeAttr('readonly');
                            $("#mat_location").removeAttr('readonly');
                            $("#mat_abc").removeAttr('readonly');
                            $("#mat_typ").removeAttr('readonly');
                            $("#mat_accd").removeAttr('readonly');
                            $("#mat_opqty").removeAttr('readonly');
                            $("#mat_oprate").removeAttr('readonly');
                            $("#mat_opdate").removeAttr('readonly');
                            $("#mat_budg").removeAttr('readonly');
                        }
                    }
                    else if(data.itm_desc == '')
                    {                        
                        document.getElementById('ComItmCdErrorSpan').innerHTML="Invalid Item Code";
                        document.getElementById('ComItmCdName').innerHTML="";
                        ItmCd.focus();
                    } 
                }
            }
            xmlhttp.open("GET","includes/cmp_itm_cd_chck.php?q="+ItmCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value+"&UserComDbf="+UserComDbf.value+"&UserUntCd="+UserUntCd.value+"&UserComCd="+UserComCd.value,true);
            xmlhttp.send();
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////

    // company code check for supplier master
    // validation for company code check
    function CheckSubMastComCd(){
        var UserComCd = document.getElementById('user_com_cd');
        //alert(UserComCd.value);
        if(UserComCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    if(value.length < 1)
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="Invalid Company Code";
                        document.getElementById('ComCdName').innerHTML="";
                        UserComCd.focus();
                    }
                    else
                    {
                        document.getElementById('ComCdErrorSpan').innerHTML="";
                        document.getElementById('com_com').value=UserComCd.value;
                        document.getElementById('ComCdName').innerHTML=value;
                        $("#mat_unit").removeAttr('readonly');
                    }
                }
              }
            xmlhttp.open("GET","includes/cmp_cd_chck.php?q="+UserComCd.value,true);
            xmlhttp.send();
        }
    }


    // check general ledger code in supplier master
    function CheckSubMastGenCd(){
        var GenLedCd = document.getElementById('sub_accd');

        if(GenLedCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.gen_desc != '')
                    {
                        document.getElementById('GenLedCdErrorSpan').innerHTML="";
                        document.getElementById('GenLedCdName').innerHTML=data.gen_desc;
                        $("#sub_subcd").removeAttr('readonly');
                    }
                    else
                    {                        
                        document.getElementById('GenLedCdErrorSpan').innerHTML="Invalid Code";
                        document.getElementById('GenLedCdName').innerHTML="";
                        GenLedCd.focus();
                    }
                }
              }
            xmlhttp.open("GET","includes/supmst_genled_cd_chck.php?q="+GenLedCd.value,true);
            xmlhttp.send();
        }
    }

    // check Sub/Party code in supplier master
    function CheckSubMastSubCd(){
        var SubCd = document.getElementById('sub_subcd');
        var GenLedCd = document.getElementById('sub_accd');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var UserComCd = document.getElementById('user_com_cd');
        var UserUntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(GenLedCd.value != "" && SubCd.value != "" && UserUntCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.sub_com != '')
                    {
                        if (data.passActn == 'u') {
                            $("input").removeAttr('readonly');
                            document.getElementById('SubCdErrorSpan').innerHTML="";
                            document.getElementById('sub_desc').value=data.sub_desc;
                            document.getElementById('sub_opbal').value=data.sub_opbal;
                            document.getElementById('sub_opbaldt').value=data.sub_opbaldt;
                            document.getElementById('sub_cat').value=data.sub_cat;
                            document.getElementById('sub_agetag').value=data.sub_agetag;
                            document.getElementById('sub_pancard').value=data.sub_pancard;
                        }else if (data.passActn == 'e') {
                            document.getElementById('SubCdErrorSpan').innerHTML="Duplicate Entry";
                            SubCd.focus();
                        }else if (data.passActn == 'd' && FrmNm.value == 'submast') {
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/inv_record_del.php?q="+SubCd.value+"&GenLedCd="+GenLedCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&FrmNm="+FrmNm.value,true);
                                xmlhttp.send();
                                document.getElementById('SubCdErrorSpan').innerHTML="Record Has Been Deleted !";
                                alert("Record Deleted Successfully.");
                            }
                        }
                    }
                    else
                    {                        
                        document.getElementById('SubCdErrorSpan').innerHTML="New Entry";
                        $("input").removeAttr('readonly');
                        document.getElementById('sub_desc').value="";
                        document.getElementById('sub_opbal').value="";
                        document.getElementById('sub_opbaldt').value="";
                        document.getElementById('sub_cat').value="";
                        document.getElementById('sub_agetag').value="";
                        document.getElementById('sub_pancard').value="";
                    }
                }
              }
            xmlhttp.open("GET","includes/supmst_sub_party_cd_chck.php?q="+SubCd.value+"&GenLedCd="+GenLedCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }


    /////////////////////////////////////////// Purchase Module starts ////////////////////////////////////////////

    // check req no and srl no for purchase requisition
    function CheckIreqSrlNo(){
        var ReqDt = document.getElementById('req_dt');
        var CrntDt = document.getElementById('crnt_dt');
        var ReqFinYr = document.getElementById('req_fyr');
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');
        var ReqNo = document.getElementById('req_no');
        var ReqSrlNo = document.getElementById('req_srl');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');   
        var UserComDbf = document.getElementById('user_com_dbf');

        if(ReqDt.value != "")
        {   
            var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
            var CrntDtYr = CrntDt.value.slice(6);
            var CrntDtMth = CrntDt.value.slice(3,-5);
            var CrntDtDy = CrntDt.value.slice(0,-8); 
            var ReqDtYr = ReqDt.value.slice(6);
            var ReqDtMth = ReqDt.value.slice(3,-5);
            var ReqDtDy = ReqDt.value.slice(0,-8);

            var firstDate = new Date(CrntDtYr,CrntDtMth,CrntDtDy);
            var secondDate = new Date(ReqDtYr,ReqDtMth,ReqDtDy);

            var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
            ReqNo.focus();
            if (diffDays <= 2) {

                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                  xmlhttp=new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function()
                {
                  if (xmlhttp.readyState==4 && xmlhttp.status==200)
                    {
                        var value = xmlhttp.responseText;
                        data = JSON.parse(value);
                        if(data.req_no != '')
                        {
                            ReqFinYr.value=data.finYear;
                            if (data.passActn == 'e') {
                                ReqNo.value=data.req_no;
                                ReqSrlNo.value=data.req_srl;
                            }else if (data.passActn == 'u' || data.passActn == 'a'  || data.passActn == 'c') {
                                ReqNo.value="";
                                ReqSrlNo.value="";
                                $("#req_no").removeAttr('readonly');
                                $("#req_srl").removeAttr('readonly');
                            }
                            $("#req_dept").removeAttr('readonly');
                        }
                    }
                  }
                xmlhttp.open("GET","includes/prchs_reqno_srl_chck.php?q="+ReqDtYr.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&ComPass="+ComPass.value+"&UserComDbf="+UserComDbf.value+"&FrmNm="+FrmNm.value+"&CrntDt="+CrntDt.value+"&ReqDtYr="+ReqDtYr+"&ReqDtMth="+ReqDtMth+"&ReqDtDy="+ReqDtDy,true);
                xmlhttp.send();

            }else{
                alert('Previous Entry Before Two Days Not Allowed ....!!');
                ReqNo.value="";
                ReqSrlNo.value="";
                ReqDt.focus();
            }
        }
    }

    // check department code in deptcat for purchase requisition
    function CheckDeptDescCd(){
        var DeptCd = document.getElementById('req_dept');

        if(DeptCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.dep_desc != '')
                    {
                        document.getElementById('DeptCdErrorSpan').innerHTML="";
                        document.getElementById('DeptCdName').innerHTML=data.dep_desc;
                        $("#req_item").removeAttr('readonly');
                    }
                    else
                    {                        
                        document.getElementById('DeptCdErrorSpan').innerHTML="Invalid Code";
                        document.getElementById('DeptCdName').innerHTML="";
                        DeptCd.focus();
                    }
                }
              }
            xmlhttp.open("GET","includes/depart_desc_cd_chck.php?q="+DeptCd.value,true);
            xmlhttp.send();
        }else{
            document.getElementById('DeptCdErrorSpan').innerHTML="Required";
            DeptCd.value="";
            DeptCd.focus();
        }
    }

    // check department code in deptcat for purchase requisition
    function CheckPrchsItmCd(){
        var ItmCd = document.getElementById('req_item');   
        var UserComDbf = document.getElementById('user_com_dbf');        
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');
        var ReqDt = document.getElementById('req_dt');
        var ReqFyr = document.getElementById('req_fyr');
        var ReqNo = document.getElementById('req_no');
        var ReqSrl = document.getElementById('req_srl');
        var ReqDept = document.getElementById('req_dept');

        if(ItmCd.value != "")
        {
            var ReqDtYr = ReqDt.value.slice(6);
            var ReqDtMth = ReqDt.value.slice(3,-5);
            var ReqDtDy = ReqDt.value.slice(0,-8);

            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // Hide the image after the response from the server
                    document.getElementById("ItmCdErrorSpan").innerHTML = ''; 
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.itm_desc != '')
                    {
                        document.getElementById('ItmCdErrorSpan').innerHTML="";
                        document.getElementById('req_desc').value=data.itm_desc;
                        document.getElementById('ItmUomName').innerHTML=data.cod_desc;
                        document.getElementById('req_min_stck').value=data.mat_minlev;
                        document.getElementById('req_mx_stck').value=data.mat_maxlev;
                        document.getElementById('req_last_po').value=data.poh_po_no;
                        document.getElementById('req_srl_no').value=data.pod_po_srl;
                        document.getElementById('req_po_dt').value=data.poh_po_dt;
                        document.getElementById('req_pen_qty').value=data.pod_pen_qty;
                        document.getElementById('req_rate').value=parseFloat(Math.round(data.item_rate * 100) / 100).toFixed(4);
                        document.getElementById('req_stck').value=parseFloat(Math.round(data.item_stock * 100) / 100).toFixed(2);

                        if ((data.passActn == 'u' || data.passActn == 'a' || data.passActn == 'c') && data.req_qty != '') {
                            document.getElementById('req_qty').value=data.req_qty;
                            document.getElementById('req_rmk').value=data.req_rmk;
                            document.getElementById('req_catg').value=data.req_catg;
                            document.getElementById('req_can_qty').value=data.req_can_qty;
                            document.getElementById('req_aprvd_qty').value=data.req_aprvd_qty;
                            document.getElementById('req_cons_days').value=data.req_cons_days;
                            document.getElementById('req_inq_fyr').value=data.req_inq_fyr;
                            document.getElementById('req_inq_no').value=data.req_inq_no;
                            $('#req_qty').focus();
                            if (data.passActn == 'a') {
                                $('#req_aprvd_qty').focus();                                
                            }else if (data.passActn == 'c') {
                                $('#req_can_qty').removeAttr('readonly');
                                $('#req_can_qty').focus();
                            }else{
                                $('#req_desc').focus();
                            }
                        }else if ((data.passActn == 'u' || data.passActn == 'a' || data.passActn == 'c') && data.req_qty == '') {
                            document.getElementById('ItmCdErrorSpan').innerHTML="Not Found";
                            ItmCd.focus();

                            document.getElementById('req_desc').value="";
                            document.getElementById('ItmUomName').innerHTML="";
                            document.getElementById('req_min_stck').value="";
                            document.getElementById('req_mx_stck').value="";
                            document.getElementById('req_last_po').value="";
                            document.getElementById('req_srl_no').value="";
                            document.getElementById('req_po_dt').value="";
                            document.getElementById('req_pen_qty').value="";
                            document.getElementById('req_rate').value="";
                            document.getElementById('req_stck').value="";
                        }

                        if (data.passActn == 'a') {
                            $("#req_srl").removeAttr('readonly'); 
                            $("#req_aprvd_qty").removeAttr('readonly');                            
                        }

                        $("#req_qty").removeAttr('readonly');
                        $("#req_rmk").removeAttr('readonly');
                        $("#req_desc").removeAttr('readonly');
                        $("#req_catg").removeAttr('readonly');
                        $("#req_cons_days").removeAttr('readonly');
                        $("#req_inq_fyr").removeAttr('readonly');
                        $("#req_inq_no").removeAttr('readonly');
                    }
                    else
                    {
                        document.getElementById('ItmCdErrorSpan').innerHTML="Invalid Code";
                        ItmCd.value="";
                        ItmCd.focus();
                        document.getElementById('req_desc').value="";                        
                        document.getElementById('ItmUomName').innerHTML="";
                        document.getElementById('req_min_stck').value="";
                        document.getElementById('req_mx_stck').value="";
                        document.getElementById('req_last_po').value="";
                        document.getElementById('req_srl_no').value="";
                        document.getElementById('req_po_dt').value="";
                        document.getElementById('req_pen_qty').value="";
                        document.getElementById('req_rate').value="";
                        document.getElementById('req_stck').value="";
                    }
                }
              }

            // Set here the image before sending request
            document.getElementById("ItmCdErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 

            xmlhttp.open("GET","includes/prchs_item_cd_chck.php?q="+ItmCd.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value+"&UserComDbf="+UserComDbf.value+"&ReqDtYr="+ReqDtYr+"&ReqDtMth="+ReqDtMth+"&ReqDtDy="+ReqDtDy+"&ReqFyr="+ReqFyr.value+"&ReqNo="+ReqNo.value+"&ReqSrl="+ReqSrl.value+"&ReqDt="+ReqDt.value+"&ReqDept="+ReqDept.value,true);
            xmlhttp.send();
        }else{
            document.getElementById('ItmCdErrorSpan').innerHTML="Required";
            ItmCd.value="";
            ItmCd.focus();
        }
    }

    // check request qty with net requirment for purchase requisition
    function CheckPrchsReqQty(){
        var ReqQty = document.getElementById('req_qty');
        var NetReq = document.getElementById('req_net_req');
        var Stock = document.getElementById('req_stck');
        var MinStock = document.getElementById('req_min_stck');
        //alert(ReqQty.value.length);
        if (ReqQty.value.length != 0 && ReqQty.value != '.') {
            ReqQty.value=parseFloat(Math.round(ReqQty.value * 100) / 100).toFixed(2);
            NetReq.value = parseFloat(ReqQty.value) - parseFloat(Stock.value) + parseFloat(MinStock.value);
            
            document.getElementById('ReqQtyCdErrorSpan').innerHTML="";
        }else{
            document.getElementById('ReqQtyCdErrorSpan').innerHTML="Not a number";
            ReqQty.value="";
            ReqQty.focus();
        }
    }


    /////////////////////////////////////////////////////////////////////////////////


    // check last po date, inq no and inq fyr for purchase order
    function CheckPoInqNo(){
        var PoDt = document.getElementById('poh_po_dt');
        var CrntDt = document.getElementById('crnt_dt');
        var PoFinYr = document.getElementById('poh_fyr');
        var PoFinYr1 = document.getElementById('poh_fyr1');
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');
        var PoNo = document.getElementById('poh_po_no');
        var PoInqNo = document.getElementById('poh_inq_no');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');
        var UserComDbf = document.getElementById('user_com_dbf');

        if(PoInqNo.value != "" && PoInqNo.value == 999999)
        {   
            document.getElementById("PoInqNoErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.poh_po_no != '' && data.passActn == 'e') {
                        PoFinYr.value=data.finYear;
                        PoNo.value=data.poh_po_no;
                        PoFinYr1.value=data.finYear;
                        $("#poh_po_type").removeAttr('readonly');
                    }else if (data.poh_po_no != '' && data.passActn == 'u') {
                        PoFinYr.value=data.finYear;
                        PoFinYr1.value=data.finYear;
                        $("input").removeAttr('readonly');
                    }else if (data.poh_po_no != '' && data.passActn == 'd') {
                        PoFinYr.value=data.finYear;
                        PoFinYr1.value=data.finYear;
                        $("#poh_po_no").removeAttr('readonly');
                    }

                }
            }
            xmlhttp.open("GET","includes/prchs_porder_pono_chck.php?q="+PoInqNo.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&ComPass="+ComPass.value+"&UserComDbf="+UserComDbf.value+"&FrmNm="+FrmNm.value+"&CrntDt="+CrntDt.value,true);
            xmlhttp.send();            
        }if(PoInqNo.value == "" || PoInqNo.value != 999999){
            document.getElementById("PoInqNoErrorSpan").innerHTML="Not Present";
            PoInqNo.value=""
            PoInqNo.focus();
        }
    }

    // check last po date, inq no and inq fyr for purchase order
    function CheckPoTypeCd(){
        var PoNo = document.getElementById('poh_po_type');

        if(PoNo.value != "")
        {   
            document.getElementById("PoTypeErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.cod_desc != '') {
                        document.getElementById("PoTypeErrorSpan").innerHTML=data.cod_desc;
                        $("#poh_supcd").removeAttr('readonly');
                    }else if (data.cod_desc == '') {
                        document.getElementById("PoTypeErrorSpan").innerHTML="Invalid Code";
                    }  
                }
            }
            xmlhttp.open("GET","includes/prchs_porder_potype_chck.php?q="+PoNo.value,true);
            xmlhttp.send();            
        }if(PoNo.value == ""){
            document.getElementById("PoTypeErrorSpan").innerHTML="Required";
            PoNo.focus();
        }
    }

    // check last supplier code for purchase order
    function CheckPoSupCd(){
        var PoSupCd = document.getElementById('poh_supcd');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');

        if(PoSupCd.value != "")
        {               
            document.getElementById("PoSupCdErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // unset loading image
                    document.getElementById("PoSupCdErrorSpan").innerHTML = '';
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.gen_desc != '') {
                        document.getElementById("PoSupCdErrorSpan").innerHTML=data.sup_name;
                        document.getElementById("poh_sup_accd").value=data.sup_cd;
                        document.getElementById("poh_sup_accd_desc").value=data.gen_desc;
                        document.getElementById("poh_st_cd").value=data.stCode;
                        $("#poh_dlv_dest").removeAttr('readonly');
                        $("#poh_stax_cd").removeAttr('readonly');
                        $("#poh_sup_accd").removeAttr('readonly');
                        $("#poh_sup_accd_desc").removeAttr('readonly');
                    }else if (data.gen_desc == '') {
                        document.getElementById("poh_sup_accd_desc").value="Invalid Code";
                        document.getElementById("PoSupCdErrorSpan").innerHTML="Non GST / Invalid Code";
                        PoSupCd.focus();
                    }  
                }
            }
            // Set here the image before sending request
            document.getElementById("PoSupCdErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/prchs_porder_posupcd_chck.php?q="+PoSupCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value,true);
            xmlhttp.send();            
        }if(PoSupCd.value == ""){
            document.getElementById("PoSupCdErrorSpan").innerHTML="Required";
            PoSupCd.focus();
        }
    }

    // check last po sales tax code and desc for purchase order
    function CheckPoSalTaxCd(){
        var PoSalTax = document.getElementById('poh_stax_cd');

        if(PoSalTax.value != "")
        {   
            document.getElementById("PoSalTaxErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.cod_desc != '') {
                        document.getElementById("poh_stax_desc").value=data.cod_desc;
                        $("#poh_stax_desc").removeAttr('readonly');
                        $("#poh_excise_cd").removeAttr('readonly');
                        $("#poh_stax_per").removeAttr('readonly');
                    }else if (data.cod_desc == '') {
                        document.getElementById("poh_stax_desc").value="Invalid Code";
                    }  
                }
            }
            xmlhttp.open("GET","includes/prchs_porder_posaltax_chck.php?q="+PoSalTax.value,true);
            xmlhttp.send();            
        }if(PoSalTax.value == ""){
            document.getElementById("PoSalTaxErrorSpan").innerHTML="Required";
            PoSalTax.focus();
        }
    }

    // check po excise code and desc for purchase order
    function CheckPoExciseCd(){
        var PoSalTax = document.getElementById('poh_excise_cd');

        if(PoSalTax.value != "")
        {   
            document.getElementById("PoExciseCdErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.cod_desc != '') {
                        document.getElementById("poh_excise_cd_desc").value=data.cod_desc;
                        $("#poh_excise_cd_desc").removeAttr('readonly');
                        $("#poh_disc").removeAttr('readonly');
                        $("#poh_bank").removeAttr('readonly');
                        $("#poh_paycr_days").removeAttr('readonly');
                        $("#poh_crdisc").removeAttr('readonly');
                        $("#poh_addl_rmk").removeAttr('readonly');
                        $("#poh_exp_dt").removeAttr('readonly');
                        $("#poh_pmnt_terms").removeAttr('readonly');
                        $("#pod_item").removeAttr('readonly');
                        $("#poh_gst_cd").removeAttr('readonly');
                    }else if (data.cod_desc == '') {
                        document.getElementById("PoExciseCdErrorSpan").innerHTML="Invalid Code";
                    }  
                }
            }
            xmlhttp.open("GET","includes/prchs_porder_poexcisecd_chck.php?q="+PoSalTax.value,true);
            xmlhttp.send();            
        }if(PoSalTax.value == ""){
            document.getElementById("PoExciseCdErrorSpan").innerHTML="Required";
            PoSalTax.focus();
        }
    }

    // check po excise code and desc for purchase order
    function CheckPoGstCd(){
        var GstCd = document.getElementById('poh_gst_cd');
        var GstCdPer = document.getElementById('poh_gst_per');
        var IgstPer = document.getElementById('poh_igst_per');
        var SgstPer = document.getElementById('poh_sgst_per');
        var CgstPer = document.getElementById('poh_cgst_per');
        var UgstPer = document.getElementById('poh_ugst_per');
        var StCd = document.getElementById('poh_st_cd');
        if(GstCd.value != "")
        {   
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.gstPer != '') {
                        document.getElementById("PoGstCdErrorSpan").innerHTML="";
                        $("#poh_gst_per").removeAttr('readonly');
                        GstCdPer.value=data.gstPer;
                        IgstPer.value=data.igstPer;
                        SgstPer.value=data.sgstPer;
                        CgstPer.value=data.cgstPer;
                        UgstPer.value=data.ugstPer;
                        $("#poh_igst_per").removeAttr('readonly');                        
                        $("#poh_sgst_per").removeAttr('readonly');
                        $("#poh_cgst_per").removeAttr('readonly');
                        $("#poh_ugst_per").removeAttr('readonly');
                    }else if (data.gstPer == '') {
                        document.getElementById("PoGstCdErrorSpan").innerHTML="Invalid Code";
                        GstCd.value="";
                        GstCdPer.value='0.00';
                        IgstPer.value='0.00';
                        SgstPer.value='0.00';
                        CgstPer.value='0.00';
                        UgstPer.value='0.00';
                        GstCd.focus();
                    }  
                }
            }
            xmlhttp.open("GET","includes/prchs_porder_pogstcd_chck.php?q="+GstCd.value+"&StCd="+StCd.value,true);
            xmlhttp.send();            
        }if(GstCd.value == ""){
            document.getElementById("PoGstCdErrorSpan").innerHTML="Required";
            GstCd.focus();
        }
    }

    // check po pod srl code for po no in purchase order
    function CheckPoSrlCd(){
        var PoNo = document.getElementById('poh_po_no');
        var PoFinYr = document.getElementById('poh_fyr');
        var ComCd = document.getElementById('user_com_cd');
        var UntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');
        var UserComDbf = document.getElementById('user_com_dbf');

        if(PoNo.value != "")
        {   
            document.getElementById("PoExciseCdErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.pod_po_srl != '' && data.passActn == 'e') {
                        document.getElementById("pod_po_srl").value=data.pod_po_srl;
                    }
                }
            }
            xmlhttp.open("GET","includes/prchs_porder_posrlno_chck.php?q="+PoNo.value+"&PoFinYr="+PoFinYr.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&UserComDbf="+UserComDbf.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();            
        }
    }


    // check po item code for purchase order
    function CheckPoItemCd(){
        var PoItemNo = document.getElementById('pod_item');
        var PoNo = document.getElementById('poh_po_no');
        var PoFinYr = document.getElementById('poh_fyr');
        var CrntDt = document.getElementById('crnt_dt');
        var ComCd = document.getElementById('user_com_cd');
        var UntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');
        var UserComDbf = document.getElementById('user_com_dbf');

        if(PoItemNo.value != "")
        {
            
            document.getElementById("PoItemErrorCd").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // unset loading image
                    document.getElementById("PoItemErrorCd").innerHTML = '';
                    var value = xmlhttp.responseText;
                    document.getElementById("item_data").innerHTML=value;
                    $("#pod_rate").removeAttr('readonly');
                    $("#pod_ord_qty").removeAttr('readonly');
                    $("#pod_tolerance").removeAttr('readonly');
                    $("#pod_tech_spec").removeAttr('readonly');
                }
            }
            // Set here the image before sending request
            document.getElementById("PoItemErrorCd").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/prchs_porder_poitemno_chck.php?q="+PoItemNo.value+"&PoFinYr="+PoFinYr.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&UserComDbf="+UserComDbf.value,true);
            xmlhttp.send();            
        }if(PoItemNo.value == ""){
            document.getElementById("PoItemErrorCd").innerHTML="Required";
            PoItemNo.focus();
        }
    }

    // change po order qty
    function ChangePoOrdQty(data){
        var OrdQty = document.getElementById('pod_ord_qty');
        var TotalOrdQty = OrdQty.value;
        if (data == 0) {
            TotalOrdQty = 0 + parseInt(data);
        }else if (data != 0){
            TotalOrdQty = parseInt(TotalOrdQty) + parseInt(data);
        }
        OrdQty.value=parseFloat(Math.round(TotalOrdQty * 100) / 100).toFixed(3);
    }

    // add new comm details row 
    function addNewRowCommDet(){
        var container = document.getElementById("add_new_row_comm");
        container.append("<table><tr><td>Hello</td></tr></table>");
    }

    $(document).ready(function(){
        $("#addCommDet").click(function(){

            $("#commercialFields").append('<tr valign="top"><td><input type="text" name="pdc_sr[]" id="req_sr"  maxlength="1" size="1"></td><td><input type="text" name="pdc_id[]" id="pdc_id"  maxlength="2" size="1"></td><td><input type="text" name="pdc_tag[]" id="pdc_tag"  maxlength="3" size="1"></td><td><input type="text" name="pdc_amt[]" id="pdc_amt"  maxlength="10" size="10" onblur="setNumberDecimal(this)"></td><td><a href="javascript:void(0);" id="remCommDet">Remove</a></td></tr>');

            $("#remCommDet").on('click',function(){
                $(this).parent().parent().remove();
            });
        });
    });

    $(document).ready(function(){
        $("#addStagDet").click(function(){

            $("#staggeredFields").append('<tr valign="top"><td><input type="text" name="pdd_sr[]" id="req_sr"  maxlength="1" size="1"></td><td><input type="date" name="pdd_sch_dt[]" id="pdd_sch_dt"  maxlength="10" size="10"></td><td><input type="text" name="pdd_stag_qty[]" id="pdd_stag_qty"  maxlength="10" size="10"></td><td><a href="javascript:void(0);" id="remStagDet">Remove</a></td></tr>');

            $("#remStagDet").on('click',function(){
                $(this).parent().parent().remove();
            });
        });
    });



    // check purchase order number details
    function CheckPoPoNoDetails(){
        var PoPoCd = document.getElementById('poh_po_no');
        var PoInqNo = document.getElementById('poh_inq_no');
        var PoFinYr = document.getElementById('poh_fyr');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var ComCd = document.getElementById('com_com');
        var UntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(PoPoCd.value != "")
        {               
            document.getElementById("PoPoCdErrorSpan").innerHTML="";
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    // unset loading image
                    document.getElementById("PoPoCdErrorSpan").innerHTML = '';
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if (data.poh_supcd != '' && data.passActn == 'u') {
                        document.getElementById("poh_po_type").value=data.poh_po_type;
                        document.getElementById("poh_supcd").value=data.poh_supcd;
                        document.getElementById("poh_sup_accd").value=data.poh_sup_accd;
                        document.getElementById("poh_dlv_dest").value=data.poh_dlv_dest;
                        document.getElementById("poh_stax_cd").value=data.poh_stax_cd;
                        document.getElementById("poh_excise_cd").value=data.poh_excise_cd;
                        document.getElementById("poh_disc").value=data.poh_disc;
                        document.getElementById("poh_bank").value=data.poh_bank;
                        document.getElementById("poh_gst_cd").value=data.poh_gst_cd;
                        document.getElementById("poh_gst_per").value=data.poh_gst_per;
                        document.getElementById("poh_igst_per").value=data.poh_igst_per;
                        document.getElementById("poh_sgst_per").value=data.poh_sgst_per;
                        document.getElementById("poh_cgst_per").value=data.poh_cgst_per;
                        document.getElementById("poh_ugst_per").value=data.poh_ugst_per;
                        document.getElementById("poh_paycr_days").value=data.poh_paycr_days;
                        document.getElementById("poh_crdisc").value=data.poh_crdisc;
                        document.getElementById("poh_addl_rmk").value=data.poh_addl_rmk;
                        document.getElementById("poh_exp_dt").value=data.poh_exp_dt;
                        document.getElementById("poh_pmnt_terms").value=data.poh_pmnt_terms;

                        document.getElementById("pod_po_srl").value=data.pod_po_srl;
                        document.getElementById("pod_item").value=data.pod_item;
                        document.getElementById("pod_rate").value=data.pod_rate;
                        document.getElementById("pod_ord_qty").value=data.pod_ord_qty;
                        document.getElementById("pod_tolerance").value=data.pod_tolerance;
                        document.getElementById("pod_tech_spec").value=data.pod_tech_spec;

                        document.getElementById("toUpdatePdcData").innerHTML=data.pdc_data;
                        document.getElementById("hidePdcOnupd").remove();
                        document.getElementById("toUpdatePddData").innerHTML=data.pdd_data;
                        document.getElementById("hidePddOnupd").remove();
                    }else if (data.poh_supcd == '' && data.passActn == 'u') {
                        document.getElementById("PoPoCdErrorSpan").innerHTML="Audit Done";
                        PoPoCd.focus();
                    }else if (data.poh_supcd != '' && data.passActn == 'd') {
                        document.getElementById("PoPoCdErrorSpan").innerHTML="delete";
                        var strconfirm = confirm("Are you sure you want to delete?");
                        if (strconfirm == true) {
                            xmlhttp.open("GET","includes/inv_record_del.php?q="+PoPoCd.value+"&PoFinYr="+PoFinYr.value+"&UserComDbf="+UserComDbf.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
                            xmlhttp.send();
                            alert("Record Deleted Successfully.");
                            document.getElementById('PoPoCdErrorSpan').innerHTML="Record Deleted.";
                            PoPoCd.value="";
                        }
                        //PoPoCd.focus();
                    }  
                }
            }
            // Set here the image before sending request
            document.getElementById("PoPoCdErrorSpan").innerHTML = '<div style="margin: 0px; padding: 0px; position: fixed; right: 0px; top: 0px; width: 100%; height: 100%; background-color: rgb(102, 102, 102); z-index: 30001; opacity: 0.7;"><img src="img/ajax-loader1.gif" style="margin: 280px 0 0 420px;"/></div>'; 
            xmlhttp.open("GET","includes/prchs_porder_po_details_chck.php?q="+PoPoCd.value+"&PoInqNo="+PoInqNo.value+"&PoFinYr="+PoFinYr.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&ComCd="+ComCd.value+"&UntCd="+UntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();            
        }if(PoSupCd.value == ""){
            document.getElementById("PoPoCdErrorSpan").innerHTML="Required";
            PoSupCd.focus();
        }
    }


</script>

<!-- 
////////////////////////////////////////////////////////////////////////////////////////////

                                    Finac section start

//////////////////////////////////////////////////////////////////////////////////////////// -->

<script type="text/javascript">

    // validation for General Ledger A/cs Catalogue
    function ChckFrmFldsCodeDsc(){
        var Cd = document.getElementById('gen_accd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(Cd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.gen_accd != '')
                    {
                        if(data.passActn == 'e' && FrmNm.value == 'gencat'){
                            document.getElementById('GenCdErrorSpan').innerHTML="Entry Already Exists.";
                            document.getElementById("gen_desc").value=data.gen_desc;
                        }else if(data.passActn == 'u' && FrmNm.value == 'gencat') {
                            document.getElementById('GenCdErrorSpan').innerHTML="Entry Found";
                            $("input").removeAttr('readonly');
                            document.getElementById("gen_desc").value=data.gen_desc;
                        }else if (data.passActn == 'd' && FrmNm.value == 'gencat' && Cd.value != ''){
                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/fin_ctlg_del.php?q="+Cd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                                xmlhttp.send();
                                alert("Record Deleted Successfully.");
                                document.getElementById('GenCdErrorSpan').innerHTML="Record Deleted Successfully.";
                                Cd.focus();
                                document.getElementById('gen_accd').value='';
                            }
                        }
                    }
                    else if(data.gen_accd == '')
                    {
                        if(data.passActn == 'e' && FrmNm.value == 'gencat'){
                            document.getElementById('GenCdErrorSpan').innerHTML="New Entry";
                            $("input").removeAttr('readonly');
                            document.getElementById("gen_desc").value="";
                        }else if(data.passActn == 'u' && FrmNm.value == 'gencat') {
                            document.getElementById('GenCdErrorSpan').innerHTML="Entry does not exists.";
                            Cd.focus();
                            document.getElementById("gen_desc").value="";
                        }
                    }
                }
              }
                xmlhttp.open("GET","includes/fin_ctlg_gnrl_cd_chck.php?q="+Cd.value+"&FrmNm="+FrmNm.value+"&ComPass="+ComPass.value,true);
                xmlhttp.send();
        }
    }

    // check account code for Accounts Master
    function CheckAccMastGenCd(){
        var AccCd = document.getElementById('acm_accd');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var UserComCd = document.getElementById('user_com_cd');
        var UserUntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(AccCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.gen_desc != '')
                    {
                        if (data.passActn == 'e' && (data.acm_com != false || data.acm_com != '')) {
                            document.getElementById('AccMstrCdErrorSpan').innerHTML="Entry Already Exists.";
                            AccCd.focus();
                        }else if (data.passActn == 'e' && (data.acm_com == false || data.acm_com == '')) {
                            document.getElementById('AccMstrCdErrorSpan').innerHTML=data.gen_desc;
                            $("input").removeAttr('readonly');
                        }else if (data.passActn == 'u' && (data.acm_com != false || data.acm_com != '')) {
                            document.getElementById('AccMstrCdErrorSpan').innerHTML=data.gen_desc;
                            $("input").removeAttr('readonly');
                            document.getElementById("acm_opbal").value=data.acm_opbal;
                            document.getElementById("acm_baldt").value=data.acm_baldt;
                            document.getElementById("acm_sublink").value=data.acm_sublink;
                            document.getElementById("acm_prtag").value=data.acm_prtag;
                            document.getElementById("acm_bal").value=data.acm_bal;
                            document.getElementById("acm_sch").value=data.acm_sch;
                            document.getElementById("acm_schsrl").value=data.acm_schsrl;
                            document.getElementById("acm_budget").value=data.acm_budget;
                        }else if (data.passActn == 'u' && (data.acm_com == false || data.acm_com == '')) {
                            document.getElementById('AccMstrCdErrorSpan').innerHTML="Entry Not Found.";
                            AccCd.focus();
                            document.getElementById("acm_opbal").value="";
                            document.getElementById("acm_baldt").value="";
                            document.getElementById("acm_sublink").value="";
                            document.getElementById("acm_prtag").value="";
                            document.getElementById("acm_bal").value="";
                            document.getElementById("acm_sch").value="";
                            document.getElementById("acm_schsrl").value="";
                            document.getElementById("acm_budget").value="";
                        }else if (data.passActn == 'd' && (data.acm_com != false || data.acm_com != '')) {

                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/fin_ctlg_del.php?q="+AccCd.value+"&UserUntCd="+UserUntCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&FrmNm="+FrmNm.value,true);
                                xmlhttp.send();
                                alert("Record Deleted Successfully.");
                                document.getElementById('AccMstrCdErrorSpan').innerHTML="Record Deleted Successfully.";
                                AccCd.focus();
                                document.getElementById('acm_accd').value='';
                            }
                        }
                    }
                    else
                    {                        
                        document.getElementById('AccMstrCdErrorSpan').innerHTML="Invalid Account Code";
                        document.getElementById('AccMstrCdName').innerHTML="";
                        AccCd.focus();
                        document.getElementById("acm_opbal").value="";
                        document.getElementById("acm_baldt").value="";
                        document.getElementById("acm_sublink").value="";
                        document.getElementById("acm_prtag").value="";
                        document.getElementById("acm_bal").value="";
                        document.getElementById("acm_sch").value="";
                        document.getElementById("acm_schsrl").value="";
                        document.getElementById("acm_budget").value="";
                    }
                }
              }
            xmlhttp.open("GET","includes/accmst_genled_cd_chck.php?q="+AccCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }


    // check book code for Book Master
    function CheckBkMastBkCd(){
        var BkCd = document.getElementById('bkm_code');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var UserComCd = document.getElementById('user_com_cd');
        var UserUntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(BkCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.bkm_com != '') {
                        if (data.passActn == 'e') {
                            document.getElementById('BkMastBkCdErrorSpan').innerHTML="Entry Already Exists.";
                            BkCd.focus();
                        }else if (data.passActn == 'u') {
                            $("input").removeAttr('readonly');
                            document.getElementById("bkm_desc").value=data.bkm_desc;
                            document.getElementById("bkm_accd").value=data.bkm_accd;
                            document.getElementById("bkm_opbal").value=data.bkm_opbal;
                            document.getElementById("bkm_baldt").value=data.bkm_baldt;
                            document.getElementById("bkm_prefix").value=data.bkm_prefix;
                        }else if (data.passActn == 'd') {

                            var strconfirm = confirm("Are you sure you want to delete?");
                            if (strconfirm == true) {
                                xmlhttp.open("GET","includes/fin_ctlg_del.php?q="+BkCd.value+"&UserUntCd="+UserUntCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&FrmNm="+FrmNm.value,true);
                                xmlhttp.send();
                                alert("Record Deleted Successfully.");
                                document.getElementById('BkMastBkCdErrorSpan').innerHTML="Record Deleted Successfully.";
                                BkCd.focus();
                                document.getElementById('bkm_code').value='';
                            }
                        }
                    }else if(data.bkm_com == ''){  
                        if (data.passActn == 'e') {
                            document.getElementById('BkMastBkCdErrorSpan').innerHTML="New Entry";
                            $("#bkm_desc").removeAttr('readonly');
                            $("#bkm_accd").removeAttr('readonly');
                            document.getElementById("acm_opbal").value="";
                            document.getElementById("acm_baldt").value="";
                            document.getElementById("acm_sublink").value="";
                            document.getElementById("acm_prtag").value="";
                            document.getElementById("acm_bal").value="";
                            document.getElementById("acm_sch").value="";
                            document.getElementById("acm_schsrl").value="";
                            document.getElementById("acm_budget").value="";
                        }else if (data.passActn == 'u') {
                            document.getElementById('BkMastBkCdErrorSpan').innerHTML="Entry Not Found.";
                            BkCd.focus();
                            document.getElementById("bkm_desc").value="";
                            document.getElementById("bkm_accd").value="";
                            document.getElementById("bkm_opbal").value="";
                            document.getElementById("bkm_baldt").value="";
                            document.getElementById("bkm_prefix").value="";
                        }
                    }
                }
            }
            xmlhttp.open("GET","includes/bkmst_bkcd_chck.php?q="+BkCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }

    // check account code for Book Master
    function CheckBkMastAcCd(){
        var AcCd = document.getElementById('bkm_accd');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(AcCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.gen_desc != '')
                    {
                        document.getElementById('BkMastAcCdErrorSpan').innerHTML=data.gen_desc;
                        $("input").removeAttr('readonly');
                    }
                    else if(data.gen_desc == '')
                    {                        
                        document.getElementById('BkMastAcCdErrorSpan').innerHTML="Invalid Account Code";
                        AcCd.focus();
                        document.getElementById("bkm_accd").value="";
                    }
                }
              }
            xmlhttp.open("GET","includes/bkmst_bkcd_chck.php?q="+AcCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }

     // check account code for Budget Master
    function CheckBdgtMastAcCd(){
    var AccCd = document.getElementById('bud_accd');
    var UserFduser = document.getElementById('user_fduser');
    var UserComDbf = document.getElementById('user_com_dbf');
    var UserComCd = document.getElementById('user_com_cd');
    var UserUntCd = document.getElementById('mat_unit');
    var ComPass = document.getElementById('comm_pass');
    var FrmNm = document.getElementById('frm_nm');

    if(AccCd.value != "")
    {
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function()
        {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
                var value = xmlhttp.responseText;
                data = JSON.parse(value);
                if(data.gen_desc != '')
                {
                    if (data.passActn == 'e' && (data.bud_com != false || data.bud_com != '')) {
                        document.getElementById('BdgtMastAcCdErrorSpan').innerHTML="Entry Already Exists.";
                        AccCd.focus();
                    }else if (data.passActn == 'e' && (data.bud_com == false || data.bud_com == '')) {
                        document.getElementById('BdgtMastAcCdErrorSpan').innerHTML=data.gen_desc;
                        $("#bud_yy").removeAttr('readonly');
                        $("#bud_mm").removeAttr('readonly');
                        $("#bud_subcd").removeAttr('readonly');
                    }else if (data.passActn == 'u' && (data.bud_com != false || data.bud_com != '')) {
                        document.getElementById('BdgtMastAcCdErrorSpan').innerHTML=data.gen_desc;
                        $("input").removeAttr('readonly');
                        document.getElementById("bud_yy").value=data.bud_yy;
                        document.getElementById("bud_mm").value=data.bud_mm;
                        document.getElementById("bud_accd").value=data.bud_accd;
                        document.getElementById("bud_subcd").value=data.bud_subcd;
                        document.getElementById("bud_bud_amt").value=data.bud_bud_amt;
                        document.getElementById("bud_act_amt").value=data.bud_act_amt;
                        document.getElementById("bud_sublink").value=data.bud_sublink;
                    }else if (data.passActn == 'u' && (data.bud_com == false || data.bud_com == '')) {
                        document.getElementById('BdgtMastAcCdErrorSpan').innerHTML="Entry Not Found.";
                        AccCd.focus();
                        document.getElementById("bud_yy").value="";
                        document.getElementById("bud_mm").value="";
                        document.getElementById("bud_accd").value="";
                        document.getElementById("bud_subcd").value="";
                        document.getElementById("bud_bud_amt").value="";
                        document.getElementById("bud_act_amt").value="";
                        document.getElementById("bud_sublink").value="";
                    }else if (data.passActn == 'd' && (data.bud_com != false || data.bud_com != '')) {

                        var strconfirm = confirm("Are you sure you want to delete?");
                        if (strconfirm == true) {
                            xmlhttp.open("GET","includes/fin_ctlg_del.php?q="+AccCd.value+"&UserUntCd="+UserUntCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&FrmNm="+FrmNm.value,true);
                            xmlhttp.send();
                            alert("Record Deleted Successfully.");
                            document.getElementById('BdgtMastAcCdErrorSpan').innerHTML="Record Deleted Successfully.";
                            document.getElementById('bud_accd').value='';
                        }
                    }
                }
                else
                {                        
                    document.getElementById('BdgtMastAcCdErrorSpan').innerHTML="Invalid Account Code";
                    AccCd.focus();
                    document.getElementById("bud_yy").value="";
                    document.getElementById("bud_mm").value="";
                    document.getElementById("bud_accd").value="";
                    document.getElementById("bud_subcd").value="";
                    document.getElementById("bud_bud_amt").value="";
                    document.getElementById("bud_act_amt").value="";
                    document.getElementById("bud_sublink").value="";
                }
            }
          }
            xmlhttp.open("GET","includes/bdgtmst_genled_cd_chck.php?q="+AccCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }


    // check sub accd code for Book Master
    function CheckBkMastSubAccCd(){
        var SubAccCd = document.getElementById('bud_subcd');
        var AccCd = document.getElementById('bud_accd');
        var UserFduser = document.getElementById('user_fduser');
        var UserComDbf = document.getElementById('user_com_dbf');
        var UserComCd = document.getElementById('user_com_cd');
        var UserUntCd = document.getElementById('mat_unit');
        var ComPass = document.getElementById('comm_pass');
        var FrmNm = document.getElementById('frm_nm');

        if(SubAccCd.value != "")
        {
            if (window.XMLHttpRequest)
            {// code for IE7+, Firefox, Chrome, Opera, Safari
              xmlhttp=new XMLHttpRequest();
            }
            else
            {// code for IE6, IE5
              xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function()
            {
              if (xmlhttp.readyState==4 && xmlhttp.status==200)
                {
                    var value = xmlhttp.responseText;
                    data = JSON.parse(value);
                    if(data.sub_com != '')
                    {
                        document.getElementById('BkMastSubAccCdErrorSpan').innerHTML=data.sub_desc;
                        $("input").removeAttr('readonly');
                    }
                    else if(data.sub_com == '')
                    {                        
                        document.getElementById('BkMastSubAccCdErrorSpan').innerHTML="Invalid Sub Accd Code";
                        SubAccCd.focus();
                    }
                }
              }
            xmlhttp.open("GET","includes/bdgtmst_subaccd_chck.php?q="+SubAccCd.value+"&AccCd="+AccCd.value+"&UserFduser="+UserFduser.value+"&UserComDbf="+UserComDbf.value+"&UserComCd="+UserComCd.value+"&UserUntCd="+UserUntCd.value+"&ComPass="+ComPass.value+"&FrmNm="+FrmNm.value,true);
            xmlhttp.send();
        }
    }
    
</script>