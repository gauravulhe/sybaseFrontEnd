				<ul>
                    <li><a href="#"><img src="img/home.png" width="20px"></a></li>
                      
				    <li><a href="#">Catalogues & Masters</a>
				        <ul>
				            <li><a href="">Items Catalogue</a></li>
				            <li><a href="">Party Catalogue</a></li>
				            <li><a href="">Rate Catalogue</a></li>
				            <li><a href="">Finished Goods Master</a></li>
				            <li><a href="">General Codes Master</a></li>
				            <li><a href="">Consignee Master</a></li>
				            <li><a href="">E.E.C. Master</a></li>
				            <li><a href="">Company Master</a></li>
				            <li><a href="">Representative Name</a></li>
				            <li><a href="">Representative Master</a></li>
				            <li><a href="">Item Updation</a></li>
				            <li><a href="">Submaster Entry</a></li>
				        </ul>
				    </li>
				    <li><a href="#">Orders</a>
				        <ul>
				            <li><a href=""></i>Sale Order (Entry & Printing)</a></li>
				            <li><a href=""></i>Partywise Sale orders report</a></li>
				            <li><a href=""></i>Daily Realisation Report</a></li>
				            <li><a href=""></i>Orderwise Inspecton Status</a></li>
				            <li><a href=""></i>Sales Order Cancelation</a></li>
				        </ul>
				    </li>
				    <li><a href="#">Stock    
				        <ul>
				            <li><a href="">Fin.Goods Transactions</a></li>
				            <li><a href="">Inspection Entry</a></li>
				            <li><a href="">Transfer Stock Production Book</a></li>
				            <li><a href="">Rejecton / Return Freight</a></li>
				            <li><a href="#">Monthly Stock Plan</a>
				                <ul>
				                    <li><a href=""> 1. Min./Max. Stock Entry</a></li>
				                    <li><a href=""> 2. Monthly Projection Entry</a></li>
				                    <li><a href=""> 3. Report</a></li>
				                </ul>
				            </li>
				        </ul>
				    </li>
				    <li><a href="#">Despatch</a>
				        <ul>
				            <li><a href="">Despatch Information to TRANS.</a></li>
				            <li><a href="">Loading Schedule</a></li>
				            <li><a href="">Loading</a></li>
				            <li><a href="sales_desp_chal_print.php?pid=sal">Despatch Challan (Entry/Print)</a></li>
				            <li><a href="">Freight Advice (Entry/Print)</a></li>
				            <li><a href="">Finac Freight Advice</a></li>
				            <li><a href="">TDS Declaration</a></li>
				            <li><a href="#">57-F4 Challan</a>
				                <ul>
				                    <li><a href=""> 1. Challan Entry</a></li>
				                    <li><a href=""> 2. Receipt Entry</a></li>
				                    <li><a href=""> 3. Challan Delete</a></li>
				                    <li><a href=""> 4. Receipt Delete</a></li>
				                    <li><a href=""> 5. Reports</a></li>
				                    <li><a href=""> 6. Freight Advice</a></li>
				                </ul>
				            </li>
				            
				            <li><a href="">Despatch Register</a></li>
				            <li><a href="">Daily Despatch Report</a></li>
				            <li><a href="">Bill wise despatch register</a></li>
				            <li><a href="">Bill Display</a></li>
				            <li><a href="">Cancel DESPTACH Information</a></li>
				            <li><a href="">Delete CHALLAN</a></li>
				            <li><a href="">Cancel LOADING Info</a></li>
				            <li><a href="">Party/Truck Wise Frt.Summary</a></li>
				        </ul>
				    </li>
				    <li><a href="#">M.I.S.</a>
				        <ul>
				        	<li><a href="#">Sales Analysis</a>
				                <ul>
				                    <li><a href=""> 1. Budget/Region/Reps Wise</a></li>
				                    <li><a href=""> 2. Item Wise</a></li>
				                    <li><a href=""> 3. Trading</a></li>
				                </ul>
				            </li>
				            <li><a href="">State/City wise Sales Analysis</a></li>
				            <li><a href="">State/City/Month Sales Anal. </a></li>
				            <li><a href="">Region/Party/Item Sales Anal.</a></li>
				            <li><a href="">Region/Party/Cons Sales Anal.</a></li>
				            <li><a href="">Party/Consignee Truck Details</a></li>
				            <li><a href="">Daily Truck Wise Sales Report</a></li>
				            <li><a href="">Month wise Sales Analysis</a></li>
				            <li><a href="">Bill wise age Analysis</a></li>
				            <li><a href="">Challan wise Freight details</a></li>
				            <li><a href="">All Companies Debtors Stax</a></li>
				            <li><a href="">Itemwise Realisation</a></li>
				            <li><a href="">Daily Target vs Achievement</a></li>    
				            <li><a href="">Weight Difference Report</a></li>
				            <li><a href="">Data Transfer To Foxpro</a></li>
				            <li><a href="">Bill Due Date Report</a></li>
				        </ul>
				    </li>
				    <li><a href="#">Invoice</a>
				        <ul>
				            <li><a href="">Bill Calculation & Printing</a></li>
				            <li><a href="">Railway PVC & Frt (Sup. Bill)</a></li>
				            <li><a href="">Bill Commission Entry</a></li>
				            <li><a href="">Account Code Updation</a></li>
				            <li><a href="">Sales Register</a></li>
				            <li><a href="">Sales Tax Register</a></li>
				            <li><a href="">Party/Consignee Bill Details</a></li>
				            <li><a href="">Credit Note(Cash & T.O. Disc)</a></li>
				            <li><a href="">Partywise Bill Details</a></li>
				            <li><a href="">Foreign Currency</a></li>
				        </ul>
				    </li>
				    <li><a href="#">Reports</a>
				        <ul>
				            <li><a href="">W.I.P. Ledger</a></li>
				            <li><a href="">Ledger (Finished Goods)</a></li>
				            <li><a href="">Stock Statement-Finished Goods</a></li>
				            <li><a href="">Stock Statement(TONS)- F.G.</a></li>
				            <li><a href="">Agewise Analysis</a></li>
				            <li><a href="#">Rep.wise Age Analysis</a>
				                <ul>
				                    <li><a href=""> 1. Cr note consideration</a></li>
				                    <li><a href=""> 2. Rep.Age analysis process</a></li>
				                    <li><a href=""> 3. Rep.Wise Bill/Receipt</a></li>
				                </ul>
				            </li>
				            
				            <li><a href="">Bill wise Age analysis</a></li>
				            <li><a href="">Chapter Head/Item Wise Sales</a></li>
				            <li><a href="">Item wise Detail Report</a></li>
				            <li><a href="">Party wise Detail Report</a></li>
				            <li><a href="">Dbtors Ledger/Trial Bal</a></li>
				            <li><a href="">Debtors Interest Calculation</a></li>
				            <li><a href="">Daily Bill Realisation Report</a></li>
				            <li><a href="">Finish Goods Age Analysis</a></li>
				        </ul>
				    </li>
				    <li><a href="">Printing</a></li>
				    <li><a href="#">Query</a>
				        <ul>
				            <li><a href="">Pending Sale Orders</a></li>
				            <li><a href="">Partywise Pending Sales Orders</a></li>
				            <li><a href="">Itemwise Pending Sale Orders</a></li>
				            <li><a href="">Sale Order Number Details</a></li>
				            <li><a href="">Query on Finished Goods Stock</a></li>
				        </ul>
				    </li> 
				    <li><a href="">Bhilai</a></li>
				    <li><a href="">Sales Analysys</a></li>
				    <li><a href="#">Tc Report</a>
				        <ul>
				            <li><a href="">Fox ECD</a></li>
				            <li><a href="">Fox CCD</a></li>
				            <li><a href="">Fox ACD</a></li>
				        </ul>
				    </li>
				    <li><a href="">Production</a></li>
                    <li><a href="config/logout.php">Logout</a></li>
                </ul>