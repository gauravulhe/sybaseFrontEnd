<?php 
	
	require_once('../config/config.php');

	if(isset($_GET["q"])){

		$q = $_GET["q"];

		if ($q == 'type') {
			$query = "SELECT cod_code, cod_desc FROM catalog..codecat WHERE cod_prefix = 15 AND cod_code != 0";
            echo "<h3>Purchase Order Types</h3>";
		}elseif ($q == 'supcd') {
			$query = "SELECT sup_supcd, sup_name FROM catalog..supcat";
            echo "<h3>Supplier's Details</h3>";
		}elseif ($q == 'salestax') {
			$query = "SELECT cod_code, cod_desc FROM catalog..codecat WHERE cod_prefix = 1 AND cod_code != 0";
            echo "<h3>Sales Tax Codes</h3>";
		}elseif ($q == 'excisecd') {
			$query = "SELECT cod_code, cod_desc FROM catalog..codecat WHERE cod_prefix = 2 AND cod_code != 0";
            echo "<h3>Excise Codes</h3>";
		}elseif ($q == 'payterms') {
			$query = "SELECT cod_code, cod_desc FROM catalog..codecat WHERE cod_prefix = 13 AND cod_code != 0";
            echo "<h3>Payment Terms Descriptions</h3>";
		}elseif ($q == 'itemcode') {
			$query = "SELECT * FROM catalog..itmcat";
            echo "<h3>Item Codes</h3>";
		}


		// execute the query
        $result = odbc_exec($conn, $query);
        //print(odbc_result($result, 1));
        print(odbc_result_all($result, "border=1"));
	}


	if (isset($_GET['term'])) {
	    //get search term
	    $searchTerm = $_GET['term'];
	    $srchTermType = $_GET['fldType'];
	    $fldName = $_GET['fldName'];
	    $tblName = $_GET['tblName'];

	    //get matched data from table
	    if ($srchTermType == 'int') {
	    	if (isset($_GET['cdPrfx'])) {	    		
		    	$cdPrfx = $_GET['cdPrfx'];
		    	$query = "SELECT $fldName FROM catalog..$tblName WHERE $fldName = $searchTerm AND cod_prefix = $cdPrfx AND $fldName != 0";
	    	}else{
	    		$query = "SELECT $fldName FROM catalog..$tblName";
	    	}
	    }elseif ($srchTermType == 'str'){
	    	$searchTerm = strtoupper($_GET['term']);
	    	$query = "SELECT $fldName FROM catalog..$tblName WHERE $fldName LIKE '%".$searchTerm."%'";
	    }


	    $result = odbc_exec($conn, $query);
		//print(odbc_result_all($result, "border=1"));

	    $data = odbc_result($result, 1);

		print(
			json_encode(
				array(
					$data
				)
			)
		);


		// $rows = array();
		// while($myRow = odbc_fetch_array( $result )){ 
		//     $rows[] = $myRow;//pushing into $rows array
		// }
  		
		
		// foreach($rows as $row) {
		// 	print(
		// 		json_encode(
		// 			array(
		// 				'sup_supcd' => $row['sup_supcd'],
		// 				'sup_name' => $row['sup_name']
		// 			)
		// 		)
		// 	);
		// }

	}
?>