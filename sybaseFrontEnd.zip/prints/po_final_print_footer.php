		<div class="footer">
			<table width="100%">
				<tr><td><hr></td></tr>
			</table>
			<table>
				<tr>
					<td>
						<p style="font-size:9px;">
							NOTE:-<br>
							(*)Immediate Upon dispatch 01 set of dispatch documents(advance intimation copy) must be forwarded to Manager (Purchase) & original
							invoice with all relevant quality documents as per order must be forwarded along with your material to our stores.<br>
							(*)Please mail your order acceptance as a token of acceptance of all terms and conditions of our order.<br>
							(*)Price shall remain firm till completion of contractual periods & no escalation on any account shall be payable.<br>
							(*) Any dispute concerning to this purchase order shall be subject to the jurisdiction of the court of Nagpur (Maharashtra) India only.<br>
							(*) Delivery is the essence of contract and you shall supply the material within stipulated delivery schedule. No delivery extension shall be
							issued. In case of delay beyond the delivery period stipulated in our order, liquidity damages shall be levied @ 0.5%of the contract price per
							week subject to maximum 5%of the contract price.<br>
							(*) In case of delivery failure,risk purchase clause as per JAYASWAL NECO INDUSTRIES LIMITED policy will be applicable
						</p>
					</td>
				</tr>
			</table>			
		</div>
		<div class="clear"></div>