<?php

	// server configuration
	//$serverName = "SYBLINUX";
	$serverName = "SVRSYB";
	$userName = "sa";
	$password = "master";
	$conn=odbc_connect($serverName, $userName, $password) or die("Sybase Error".odbc_error());
	session_start();

	// $result = @odbc_data_source( $conn, SQL_FETCH_FIRST );
	// while($result)
	// {
	//     echo "DSN: " . $result['server'] . " - " . $result['description'] . "<br>\n";
	//     $result = @odbc_data_source( $conn, SQL_FETCH_NEXT );	    
	// }

	//odbc_close($conn);


	//require_once('config/config.php');

	$result = @odbc_data_source( $conn, SQL_FETCH_FIRST );
	// while($result)
	// {
	//     echo "DSN: " . $result['server'] . " - " . $result['description'] . "<br>\n";
	//     $result = @odbc_data_source( $conn, SQL_FETCH_NEXT );	    
	// }


	//print(odbc_field_type($result1, 14));
	
	//$query = "SELECT * FROM catalog..comcat where com_com = 1 AND com_unit = 1";
	//$query = "SELECT * FROM catalog..codecat";
	//$query = "SELECT * FROM catalog..itmcat";
	//$query = "SELECT * FROM catalog..deptcat";
	//$query = "SELECT * FROM catalog..supeccmst";
	//$query = "SELECT * FROM catalog..shortage";
	//$query = "SELECT * FROM catalog..supcat where sup_supcd = 'N056'";
	//$query = "SELECT * FROM catalog..gencat";
	//$query = "select * from tempdb..sysobjects";
		
	// $query = "SELECT * FROM catalog.invac.request where req_com = 54 AND req_unit = 3 AND req_fyr = 2018 AND req_no = 57";
	
	// //$query = "SELECT * FROM neco.invac.parinv";
	// $result = odbc_exec($conn, $query);
	// print(odbc_result_all($result, "border=1"))."<br>";
	
	//$query = "SELECT max(par_lval) FROM neco.invac.parinv WHERE par_com = 1 AND par_unit = 1 AND par_tbl = 'pohdr' AND par_col = 1 AND par_fyr = 2017";
	//$query = "SELECT * FROM neco.invac.pohdr WHERE poh_po_no = 503 AND poh_com = 1 AND poh_unit = 1 AND poh_fyr = 2017";
	
	
	//$query = "SELECT * FROM neco.invac.matmast";
	//$query = "SELECT * FROM neco.fin1.submast";
	//$query = "SELECT * FROM catalog..itmcat WHERE itm_item = '0101340'";
	// $query = "SELECT * FROM neco.invac.request";

	// $query = "SELECT * 
	// 				FROM catalog..supcat sup
	// 				LEFT JOIN neco.fin1.submast sub
	// 				ON sup.sup_supcd = sub.sub_subcd
	// 				LEFT JOIN catalog..gencat gen
	// 				ON sub.sub_accd = gen.gen_accd WHERE sub_com = 1 AND sub_unit = 1  AND sup_stct_cd = '09127009' ORDER BY sub_accd DESC";

	// $result = odbc_exec($conn, $query);
	// print(odbc_result_all($result, "border=1"))."<br>";
	
	//$query = "UPDATE catalog..procpass SET pas_action	= 'U' WHERE pas_system = 'invac' AND pas_proc = 'supcat';

	//$query = "INSERT INTO catalog..procpass (pas_system, pas_proc, pas_action,pas_passwd) values ('invac','porder','D','delete')";
	
	//$query = "SELECT * FROM catalog..procpass WHERE pas_proc = 'supcat' AND pas_action = 'I'";

	/////////////////  finac /////////////

	//$query = "SELECT * FROM neco.fin1.submast WHERE sub_subcd = 'A002'";
	//$query = "SELECT * FROM neco.fin1.acmast";
	//$query = "SELECT * FROM neco.fin1.bkmast";
	//$query = "SELECT * FROM neco.fin1.budgmast";

	//$query = "SELECT * FROM neco.invac.podet where pod_com = 1 AND pod_unit = 1 AND	pod_po_no = 503 AND pod_fyr = 2017";
	// $query = "SELECT poh.poh_po_no, poh.poh_po_dt, pod.pod_item, poh.poh_pmnt_terms, pod.pod_ord_qty, pod.pod_rate, pod.pod_chpt_id, poh.poh_supcd, poh.poh_stax_per, poh.poh_excise_cd, poh.poh_gst_per, poh.poh_igst_per, poh.poh_sgst_per, poh.poh_cgst_per
	// 					FROM neco.invac.podet pod
	// 					INNER JOIN neco.invac.pohdr poh
	// 					ON  pod.pod_po_no = poh.poh_po_no AND 
	// 						pod.pod_unit = poh.poh_unit AND
	// 						pod.pod_fyr = poh.poh_fyr
	// 					WHERE pod.pod_unit = 1 AND pod.pod_po_no = 503 AND pod.pod_fyr = 2017 AND (poh.poh_vet_tag = 01 OR poh.poh_val_tag = 01) AND poh.poh_po_type != 09
	// 					ORDER BY poh.poh_po_dt DESC, pod.pod_po_srl DESC
	// 					";

	//$result = odbc_exec($conn, $query);
	// print(odbc_result($result, 14));
	// print(odbc_result_all($result, "border=1"))."<br>";

	// $query = "SELECT poh.poh_po_no, poh.poh_po_dt, pod.pod_item, pod.pod_po_srl, pod.pod_ord_qty , pod.pod_can_qty , pod.pod_rcv_qty , pod.pod_rej_qty  
	// 			FROM neco.invac.podet pod
	// 			INNER JOIN neco.invac.pohdr poh
	// 			ON pod.pod_po_no = poh.poh_po_no AND  
	// 				pod.pod_unit = poh.poh_unit AND
	// 				pod.pod_fyr = poh.poh_fyr
	// 			WHERE pod.pod_unit = 1 AND pod.pod_item = '0101003' AND (poh.poh_vet_tag = 01 OR poh.poh_val_tag = 01) AND poh.poh_po_type != 09
	// 			ORDER BY poh.poh_po_dt DESC, pod.pod_po_srl DESC
	// 			";

	


////////////////////////////////////////////////////////////////////////////////////////////////////////////


	$query = "SELECT * FROM catalog.invac.request where req_com = 1 AND req_unit = 1 AND req_fyr = 2017 AND req_item = '7401088' AND req_no = 153";

	$result = odbc_exec($conn, $query);
	print(odbc_result_all($result, "border=1"))."<br>";

	$query = "SELECT * FROM neco.invac.pohdr WHERE poh_com = 1 AND	poh_unit =1 AND	poh_fyr = 2017 AND poh_po_no = 442";

	//$query1 = "DELETE FROM neco.invac.pohdr WHERE poh_com = 1 AND poh_unit = 1 AND poh_fyr = 2017 AND poh_po_no = 442";
	
	$result = odbc_exec($conn, $query);
	print(odbc_result_all($result, "border=1"))."<br>";

	$query = "SELECT * FROM neco.invac.podet WHERE pod_com = 1 AND	pod_unit =1 AND	pod_fyr = 2017 AND pod_po_no = 442";
	
	$result = odbc_exec($conn, $query);
	print(odbc_result_all($result, "border=1"))."<br>";

	// $query = "SELECT * FROM neco.invac.pdcomm where pdc_com = 1 AND pdc_unit = 1 AND pdc_fyr = 2017 AND pdc_po_no = 442";
	// $result = odbc_exec($conn, $query);
	// print(odbc_result_all($result, "border=1"))."<br>";
	
	// $query = "SELECT * FROM neco.invac.pddet where pdd_com = 1 AND pdd_unit = 1 AND pdd_fyr = 2017  AND pdd_po_no = 442";
	// $result = odbc_exec($conn, $query);
	// print(odbc_result_all($result, "border=1"))."<br>";

	$query = "SELECT * FROM neco.invac.pdreq where pdr_com = 1 AND pdr_unit = 1 AND pdr_fyr = 2017  AND pdr_po_no = 442";
	$result = odbc_exec($conn, $query);
	$rows = odbc_num_rows($result);
	//print(odbc_result($result, 1)+1);
	print(odbc_result_all($result, "border=1"))."<br>";


////////////////////////////////////////////////////////////////////////////////////////////////////////////


	//$query = "SELECT req_qty, req_rmk, req_catg, req_can_qty, req_aprvd_qty, req_cons_days, req_inq_fyr, req_inq_no FROM catalog.invac.request WHERE req_com = 1 AND req_unit = 1 AND req_fyr = 2017 AND req_no = 211 AND req_srl = 1 AND req_dt = '2017-06-26' AND req_dept = 1";

	//$query = "UPDATE catalog.invac.request set req_item = '0101003', req_qty = 2.00, req_aprvd_qty = 2.000, req_can_qty = 0.000, req_rmk = 'TESTING FOR FRONT END', req_catg = 'E', req_inq_fyr = 0, req_inq_no = 0, req_cons_days = 1 where req_com = 1 AND req_unit = 1 AND req_fyr = 2017 AND req_no = 211 AND req_srl = 1 AND req_dt = '2017-06-26' AND req_dept = 1";

	// $result = odbc_exec($conn, $query);
	// print(odbc_result_all($result, "border=1"))."<br>";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//$que = "SELECT top 5 notification FROM notification order by datetime desc";
	// $query = "SELECT req_fyr,req_no,req_srl,req_dt,req_dept,req_item,req_qty,req_aprvd_qty,req_can_qty,req_ord_qty	 FROM catalog.invac.request where req_com = 1 AND req_unit = 1 AND req_fyr = 2017 AND req_item = '0101311'";
	// $queresa = odbc_exec($conn,$query);
	// $rows = array();

	// while($myRow = odbc_fetch_array( $queresa )){ 
	//     $rows[] = $myRow;//pushing into $rows array
	// }

	// //Now iterating complete array
	// foreach($rows as $row) {
	// 	// $CrntDt = date('Ymd', strtotime(date('Y-m-d h:m:s')));
	// 	// $PoReqDt = date('Ymd', strtotime($row['req_dt']));
	// 	// echo $date = $CrntDt - $PoReqDt;
	// echo '<table><tr>';
 //        foreach($row as $key => $value) {
 //            $result = $value;
 //            echo '<td>';
 //            echo $result;
 //            echo '</td>';
 //        }
	// echo '</tr></table>';
	// }

////////////////////////////////////////////////////////////////////////////////////////////////////////////



	$query = "SELECT * FROM catalog..procpass";
	$result = odbc_exec($conn, $query);
	//$rows = odbc_num_rows($result);
	print(odbc_result_all($result, "border=1"))."<br>";

////////////////////////////////////////////////////////////////////////////////////////////////////////////


	// $query = "SELECT * FROM neco.sales.bilvalue2";
	// $result = odbc_exec($conn, $query);
	// //$rows = odbc_num_rows($result);
	// print(odbc_result_all($result, "border=1"))."<br>";

	// $query = "SELECT * FROM neco.sales.challan where cha_chal_no = 3049";
	// $result = odbc_exec($conn, $query);
	// //$rows = odbc_num_rows($result);
	// print(odbc_result_all($result, "border=1"))."<br>";

	// $query = "SELECT * FROM catalog.dbo.dbtcat where dbt_ptycd = 'J287'";
	// $result = odbc_exec($conn, $query);
	// //$rows = odbc_num_rows($result);
	// print(odbc_result_all($result, "border=1"))."<br>";


/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// check if table1 exists or not
	// $tab1_check_query = "SELECT * FROM tempdb..sysobjects";
	// $tab1_result = @odbc_exec($conn, $tab1_check_query);		
	// //$tab1_name = @odbc_result($tab1_result, 1);
	// print(odbc_result_all($tab1_result, "border=1"));

////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// $queryPoGetData1 = "SELECT DISTINCT 
	// 	bil.comp,
	// 	bil.unit,
	// 	bil.chapty,
	// 	dbt.dbt_name,
	// 	dbt.dbt_add1,
	// 	dbt.dbt_add2,
	// 	dbt.dbt_add3,
	// 	dbt.dbt_stct_cd,
	// 	dbt.dbt_gstin_no,
	// 	bil.chacon,
	// 	bil.ordfyr,
	// 	bil.ordno,
	// 	itm.itm_item,
	// 	itm.itm_desc,
	// 	bil.bilno,
	// 	bil.bildt,
	// 	bil.dlvqty,
	// 	bil.actwt,
	// 	bil.rate,
	// 	bil.igst,
	// 	bil.sgst,
	// 	bil.cgst,
	// 	bil.truckno,
	// 	bil.lrno,
	// 	bil.lrdt,
	// 	cha.cha_transporter,
	// 	cha.cha_driver,
	// 	bil.ptyordno,
	// 	bil.chapt_head,
	// 	dbt.dbt_stct_cd,
	// 	bil.value,
	// 	bil.loa_no,
	// 	bil.srl,
	// 	bil.bilexcise,
	// 	bil.bilcess,
	// 	bil.bilhscs,
	// 	bil.bilstax
	// 	FROM neco.sales.bilvalue2 bil
	// 	INNER JOIN neco.sales.challan cha
	// 	ON  
	// 	bil.comp = cha.cha_com AND
	// 	bil.unit = cha.cha_unit AND
	// 	bil.bilfyr = cha.cha_fyr AND
	// 	cha.cha_chal_no = bil.bilno AND
	// 	cha.cha_chal_dt = bil.bildt
	// 	INNER JOIN catalog.dbo.dbtcat dbt
	// 	ON
	// 	dbt.dbt_ptycd = bil.chapty
	// 	INNER JOIN catalog.dbo.itmcat itm
	// 	ON
	// 	itm.itm_item = bil.item
	// 	WHERE 
	// 	bil.comp = 1 AND
	// 	bil.unit = 1 AND
	// 	bil.bilfyr = 2017 AND
	// 	bil.bildt = '201704514011' AND
	// 	bil.bilno = 47
	// ";

	// $resultGetData1 = odbc_exec($conn, $queryPoGetData1);
	// // print(odbc_result_all($resultGetData1, "border=1"));

	// $queryChal = "SELECT * FROM tempdb..blprt8221";
	// $resultChal = odbc_exec($conn, $queryChal);
	// print(odbc_result_all($resultChal, "border=1"));

	// $queryChal = "SELECT * FROM neco.sales.slhdr WHERE slh_ord_no = 3044";
	// $resultChal = odbc_exec($conn, $queryChal);
	// print(odbc_result_all($resultChal, "border=1"));

		/////////////////////////////////////////////////// digits to word //////////////

		// function foo($total_sum)
		// {
		// 	$number = $total_sum;
		// 	$str_arr = explode('.',$number);
		// 	$no = $str_arr[0];  // Before the Decimal point
		// 	$point = $str_arr[1];  // After the Decimal point
		// 	$hundred = null;
		// 	$digits_1 = strlen($no);
		// 	$i = 0;
		// 	$str = array();
		// 	$words = array('0' => '', '1' => 'ONE', '2' => 'TWO',
		// 	'3' => 'THREE', '4' => 'FOUR', '5' => 'FIVE', '6' => 'SIX',
		// 	'7' => 'SEVEN', '8' => 'EIGHT', '9' => 'NINE',
		// 	'10' => 'TEN', '11' => 'ELEVEN', '12' => 'TWELVE',
		// 	'13' => 'THIRTEEN', '14' => 'FOURTEEN',
		// 	'15' => 'FIFTEEN', '16' => 'SIXTEEN', '17' => 'SEVENTEEN',
		// 	'18' => 'EIGHTEEN', '19' =>'NINETEEN', '20' => 'TWENTY',
		// 	'30' => 'THIRTY', '40' => 'FORTY', '50' => 'FIFTY',
		// 	'60' => 'SIXTY', '70' => 'SEVENTY',
		// 	'80' => 'EIGHTY', '90' => 'NINETY');
		// 	$digits = array('', 'HUNDRED', 'THOUSAND', 'LAKH', 'CRORE');
		// 	while ($i < $digits_1) {
		// 	 $divider = ($i == 2) ? 10 : 100;
		// 	 $number = floor($no % $divider);
		// 	 $no = floor($no / $divider);
		// 	 $i += ($divider == 10) ? 1 : 2;
		// 	 if ($number) {
		// 	    $plural = (($counter = count($str)) && $number > 9) ? 'S' : null;
		// 	    $hundred = ($counter == 1 && $str[0]) ? ' AND ' : null;
		// 	    $str [] = ($number < 21) ? $words[$number] .
		// 	        " " . $digits[$counter] . $plural . " " . $hundred
		// 	        :
		// 	        $words[floor($number / 10) * 10]
		// 	        . " " . $words[$number % 10] . " "
		// 	        . $digits[$counter] . $plural . " " . $hundred;
		// 	 } else $str[] = null;
		// 	}
		// 	$str = array_reverse($str);
		// 	$result = implode('', $str);
		// 	$points = ($point) ?
		// 	" AND " . $words[$point / 10] . " " . 
		// 	      $words[$point = $point % 10] : 'ZERO';
		// 	$final_result = $result . "RUPEES  " . $points . " PAISE";
		//     return $final_result;
		// }
		
		// echo '<b>INVOICE AMOUNT : </b>'.foo(18202.50).'<br>';
		// echo '<b>CGST : </b>'.foo($total_cgst_amt).'<br>';
		// echo '<b>SGST : </b>'.foo($total_sgst_amt).'<br>';
		// echo '<b>IGST : </b>'.foo($total_igst_amt).'<br>';
		//echo '<b>TAX PAYABLE ON REVERSE CHARGE : </b>'.foo($total_taxable_amt).'<br>';

		/////////////////////////////////////////////////// digits to word //////////////

	////////// store procedure for access code

	// $link=odbc_connect("SYBLINUX","sa","master") or die("Sybase Error".odbc_error());
	// $asc_cd = 'ashmita';
	// $sql = "declare @usrpwd float
	//         exec catalog..userpwd '{$asc_cd}', @usrpwd output
	//         select usr_pwd = @usrpwd";

	////////// store procedure for fin year

	// $link=odbc_connect("SYBLINUX","sa","master") or die("Sybase Error".odbc_error());
	// $sql = "declare @fyr smallint
	//         exec catalog.dbo.finyear 41, '20170623', @fyr output
	//         select @fyr";
	// echo $sql;
	// $result = odbc_exec($conn, $sql);
	// print(odbc_result_all($result, "border=1"))."<br>";

		////////// store procedure for stock //////////////////////////

	// $link=odbc_connect("SYBLINUX","sa","master") or die("Sybase Error".odbc_error());
	// $sql = "declare @dt smalldatetime, @mm int
	// 				select @dt = convert(smalldatetime, '20170626')
	// 				exec neco.invac.stockcal '0101003', @dt, 1";
	
	// $sql = "declare @dt smalldatetime
	//  			select @dt = convert(smalldatetime, '20170626')
	//  			exec neco.invac.stockcal '6206762', @dt, 1";


	// echo $sql."</br>";
	// $result = odbc_exec($conn, $sql);
	// odbc_next_result($result);
	// //print(odbc_result($result, 1));
	// print(odbc_result_all($result, "border=1"))."<br>";

	///////////////////////////////////////////////////////////////////

	// // $itm_cd = '0101';
	// // $sql = "declare @nnum char
	// //         exec tempdb.invac.itmblnk '{$itm_cd}'
	// //         select itm_item = @nnum";

	// $sql = "select * from tempdb.invac.itmblnk";

	// echo $sql."<br>";
	// $rs = odbc_exec($link,$sql) or die("Sybase Error".odbc_error());
	// //$rsp=odbc_result($rs,1);
	// print(odbc_result_all($rs, "border=1"))."<br>";
	//echo $rsp;

	//odbc_close($conn);
?>

<?php
// /*******EDIT LINES 3-8*******/
// $DB_Server = "SVRSYB"; //MySQL Server    
// $DB_Username = "sa"; //MySQL Username     
// $DB_Password = "master";             //MySQL Password     
// $DB_DBName = "catalog";         //MySQL Database Name  
// $DB_TBLName = "catalog..comcat"; //MySQL Table Name   
// $filename = "excelfilename";         //File Name
// /*******YOU DO NOT NEED TO EDIT ANYTHING BELOW THIS LINE*******/    
// //create MySQL connection   
// $sql = "Select * from $DB_TBLName";
// $Connect = odbc_connect($DB_Server, $DB_Username, $DB_Password) or die("Couldn't connect to MySQL:<br>" . odbc_error() . "<br>" . odbc_errno());
// $result = odbc_exec($Connect,$sql) or die("Sybase Error".odbc_error());   
// $file_ending = "xls";
// //header info for browser
// header("Content-Type: application/xls");    
// header("Content-Disposition: attachment; filename=$filename.xls");
// header("Pragma: no-cache"); 
// header("Expires: 0");
// /*******Start of Formatting for Excel*******/   
// //define separator (defines columns in excel & tabs in word)
// $sep = "\t"; //tabbed character
// //start of printing column names as names of MySQL fields
// for ($i = 1; $i < odbc_num_fields($result); $i++) {
//     echo odbc_field_name($result,$i) . "\t";
// }
// echo "\n";
// //end of printing column names  
// //start while loop to get data
//     while($row = odbc_fetch_row($result))
//     {
//         $schema_insert = "";
//         for ($i = 1; $i < odbc_num_fields($result); $i++) {
//             $schema_insert .= odbc_result($result, $i).$sep;
//         }
//         $schema_insert = str_replace($sep."$", "", $schema_insert);
//         $schema_insert = preg_replace("/\r\n|\n\r|\n|\r/", " ", $schema_insert);
//         $schema_insert .= "\t";
//         print(trim($schema_insert));
//         print "\n";
//     }   
?>

<html>
<head>
	<title></title>
	<script type="text/javascript"
        src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <script type="text/javascript"
        src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
        <link rel="stylesheet" type="text/css"
        href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" />
 
        <script type="text/javascript">
                $(document).ready(function(){
                    $("#name").autocomplete({
                        source:'includes/view_details.php',
                        minLength:1
                    });
                });
        </script>
	<style type="text/css">
		body{
			/*background-image: url('img/neco_logo.png');
			background-repeat: no-repeat;
			background-position: center;*/
		}
	</style>
</head>
<body>
	<form method="post" action="">
             Name : <input type="text" id="name" name="name" />
      </form>
</body>
</html>