<?php 
	require 'pdfcrowd.php';

// create an API client instance
$client = new Pdfcrowd("gauravulhe8", "7ed4705a144a9a7332d8fcfcf970a193");
//$client = new Pdfcrowd("username", "apikey");
// convert a web page and store the generated PDF into a variable
//$pdf = $client->convertURI('http://localhost/sybaseFrontEnd/prints/po_print.php');

$pdf = $client->convertHtml("<body>My HTML Layout</body>");

//$pdf = $client->convertFile("D:/Gaurav/Work/sybaseFrontEnd/htdocs/sybaseFrontEnd/prints/po_final.php");

// set HTTP response headers
header("Content-Type: application/pdf");
header("Cache-Control: max-age=0");
header("Accept-Ranges: none");
header("Content-Disposition: attachment; filename=\"google_com.pdf\"");

// send the generated PDF 
echo $pdf;

?>